# Unified terrain–vehicle kinematic feasibility validation

## Validation protocol

A frozen Flow checkpoint is evaluated with paired Gaussian initial states. Only the inference-time objective changes; the network architecture and learned weights are unchanged. The unified objective combines vehicle-conditioned terrain cost, curvature soft excess, and lateral-acceleration soft excess.

Runtime device: `cuda`. Evaluated scenes: 128. Nominal limits: |kappa| <= 0.35 1/m and a_y <= 2.5 m/s^2.

> These are planning hyperparameters for controlled simulation, not calibrated limits of the RELLIS-3D collection vehicle. No tire-road friction, mass, wheelbase, steering limit, suspension, or roll-stability parameter is assumed.

## Results

| Scenario | Variant | minADE@K (m) | Curvature violation | Lateral-accel violation | TVK cost | Smoothness | Displacement vs Flow (m) | Latency (ms/scene) |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| nominal | Flow | 1.8944 | 0.2692 | 0.0000 | 1.9189 | 0.0230 | 0.0000 | 2.549 |
| nominal | Terrain-vehicle | 1.9045 | 0.2779 | 0.0000 | 2.1690 | 0.0230 | 0.0468 | 13.278 |
| nominal | Terrain-vehicle + curvature | 1.8887 | 0.2618 | 0.0000 | 1.7379 | 0.0229 | 0.0395 | 9.369 |
| nominal | Terrain-vehicle + lateral acceleration | 1.9045 | 0.2779 | 0.0000 | 2.1690 | 0.0230 | 0.0468 | 9.528 |
| nominal | Unified TVK | 1.8887 | 0.2618 | 0.0000 | 1.7379 | 0.0229 | 0.0395 | 9.493 |
| 4x-speed stress | Flow | 1.8944 | 0.2692 | 0.0285 | 2.8059 | 0.0230 | 0.0000 | 0.641 |
| 4x-speed stress | Unified TVK | 1.8868 | 0.2675 | 0.0286 | 2.6240 | 0.0228 | 0.0401 | 9.806 |

## Interpretation

- Unified TVK versus Flow: curvature-violation change -0.0074; relative change -2.73%; common TVK-cost change -0.1810 (-9.43%).
- Nominal lateral-acceleration violation is zero for both variants (change +0.0000); therefore this split cannot establish a nominal-condition benefit for that term.
- Fidelity trade-off: minADE@K change -0.0058 m; smoothness change -0.0002 m.
- Mean/max waypoint displacement versus paired Flow: 0.0395/0.1670 m.
- Paired TVK-cost improvement rate is 99.22%; bounded-displacement diagnostic (<5 m max) passed.
- In the explicitly labelled 4x-speed stress test, mean lateral acceleration changed by -0.0196 m/s^2 and common TVK cost by -0.1819, but threshold violation changed by +0.0001. Thus continuous-cost responsiveness is observed, while violation-rate improvement is not established.

Overall status: **partial validation**. The curvature term and unified continuous objective are effective without trajectory divergence; the lateral-acceleration term is numerically valid but its operational benefit is not supported under nominal recorded speeds and remains inconclusive under the controlled stress test.

The experiment validates a differentiable kinematic feasibility proxy, not full vehicle dynamics or safety. A dynamics/stability claim would require reliable vehicle parameters, steering constraints, tire-ground friction, and preferably measured vehicle states.
