# Continuous terrain feasibility field

## Scope and coordinate contract

The field represents one local 2.5D grid. Arrays use shape `[H_y, W_x]`: rows
increase with the caller-supplied local `y` coordinate and columns increase
with local `x`. Grid values are located at cell centres. Continuous queries
accept `[..., 2]` `(x, y)` or `[..., 3]` `(x, y, z)` tensors; the initial field
does not use query `z`.

The local audit did not establish the direction or physical axis names of the
raw RELLIS-3D LiDAR frame. Consequently, `build_terrain_field.py` does not
silently name raw sensor coordinates ego coordinates. It requires either:

1. a caller-verified homogeneous `T_ego_sensor`, for which
   `p_ego = T_ego_sensor @ p_sensor`; or
2. `--allow-unverified-identity`, which marks the archive as diagnostic and
   does **not** resolve the coordinate convention.

No undocumented semantic bit mask is applied. Stored uint32 values are matched
exactly against the configured ontology IDs.

## Feature construction

- **Elevation:** configured low percentile of point height in each cell. This
  is a robust ground proxy, not a fitted digital terrain model.
- **Slope:** `atan(sqrt((dz/dx)^2 + (dz/dy)^2))` in degrees, evaluated only
  where the cell and enough neighbouring cells contain geometry.
- **Roughness:** within-cell standard deviation of point height in metres.
- **Semantic terrain class:** exact-ID mode after classes with role `ignore`
  are removed.
- **Occupancy:** union of geometry obstacles and semantic obstacles. A geometry
  obstacle requires a configured number of returns above the cell elevation by
  the configured height threshold.
- **Clearance:** 8-connected metric distance to the nearest occupied cell,
  clipped at a configured maximum.

Missing measurements remain NaN in metric feature arrays and are accompanied
by explicit geometry, slope and semantic validity masks. Internally filled
elevation values are used only to form finite differences; they are not saved
as measured elevation.

## Continuous cost and feasibility

Each component is normalized to `[0,1]`:

```text
C = w_occ C_occ
  + w_slope C_slope
  + w_rough C_rough
  + w_sem C_sem
  + w_clear C_clearance
  + w_unknown C_unknown

F(x,y) = exp(-C(x,y))
```

`F` is bounded to `[0,1]`; larger values mean more feasible. Both cost and
feasibility maps are queried with differentiable bilinear interpolation. Field
queries outside the configured extent return zero feasibility.

Semantic costs in `configs/rellis3d_terrain_field.json` are explicitly
documented, vehicle-agnostic planning priors. They are neither supplied by the
dataset nor learned from outcomes. Water, mud, vegetation and rubble costs must
be calibrated for vehicle geometry, tyres, weather and task risk before they
are interpreted as physical traversability probabilities.

## Commands

With a verified transform:

```powershell
python scripts/build_terrain_field.py `
  --data-root <RELLIS3D_ROOT> --sequence 00004 --frame 189 `
  --sensor-to-ego <T_EGO_SENSOR.txt>
```

Diagnostic identity use is explicit:

```powershell
python scripts/build_terrain_field.py `
  --data-root <RELLIS3D_ROOT> --sequence 00004 --frame 189 `
  --allow-unverified-identity
```

Render all source layers with an aligned GT trajectory:

```powershell
python scripts/visualize_terrain_field.py `
  --field outputs/terrain_fields/00004_000189.npz `
  --trajectory <GT_TRAJECTORY.npy> `
  --output outputs/terrain_fields/00004_000189
```

The visualization preserves invalid cells as masked regions and uses nearest
neighbour raster display; it does not visually smooth or invent measurements.
