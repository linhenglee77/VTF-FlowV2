# VTF-Flow 方法框架图一致性审查

## 审查结论

当前正文引用的 `docs/figures/vtf_flow_framework_final.png` 在总体四分支逻辑上仍与方法一致，但**需要完成若干符号和流程修订后再作为最终投稿图**。`D:/Uroad/fig1.png` 的修改时间较新，但它尚未被 LaTeX 正文引用，而且仍存在与冻结方法不完全一致的标注，因此不应直接覆盖正文图。

## 必须修改

1. 将 “Goal-anchored Flow network” 改为 “Goal-conditioned Conditional Flow Matching backbone” 或 “Goal-anchored Conditional Flow Matching network”，与正文新增的 Flow Matching 启发来源及术语保持一致。
2. 将流状态维度统一写为 $\mathbf{x}_s\in\mathbb{R}^{H\times3}$，无噪估计写为 $\widehat{\mathbf{x}}_1^{(s)}\in\mathbb{R}^{H\times3}$；不得使用未定义的 $d\times3$。
3. 静态势严格写为
   $C_T(\mathbf p)=\sum_m w_m C_m(\mathbf p)/\sum_m w_m$，其中 $m\in\{o,nt,s,r,d\}$。语义标签只用于离线构建 $T$ 和 $O$，不应在图中表现为规划器的独立在线输入或额外势分量。
4. 训练分支必须明确查询的是有界相对分数 $F_{\mathrm{TVK}}=\exp(-\beta C_{\mathrm{TVK}})$，推理分支使用连续代价 $J_{\mathrm{TVK}}$ 的梯度；两者都不是经标定的安全概率。
5. 轨迹协调算子应完整体现：轨迹维平滑、逐候选 RMS 归一化、低梯度抑制、轨迹级范数裁剪，以及保持共同目标端点的投影 $\mathcal P_g$。若图中出现 “inter-vehicle/agent avoidance”，应删除，因为当前冻结实现是单车局部轨迹规划，并未实现多车交互避碰。
6. 推理更新的符号应保持一致：$\mathbf f_{\mathrm{fea},s}=-\mathcal P_g[\mathcal A(\nabla_{\mathbf x_s}J_{\mathrm{TVK}})]$，并以 $d\mathbf x/ds=\mathbf v_\theta+\eta(s)\mathbf f_{\mathrm{fea},s}$ 注入每个 Euler 步。图中应继续保留 “in-flow correction, not post-filtering”。

## 建议修改

- 第一层标题可改为 “Scene inputs and goal-conditioned CFM prior”，突出 Flow Matching 是受已有生成建模思想启发的主干，而本文创新集中在分层 TVK 势及其训练/推理耦合。
- 将底部总括句保留为 “Data-driven trajectory prior + in-flow terrain--vehicle kinematic potential correction”，它能够准确对应正文的三层创新逻辑。
- 方法图中的地形与相机小图只用于解释信息流；最终留出预测的定量和定性证据应分别引用结果章节的图 2--6，避免在方法图中放置带 oracle 含义的结果轨迹。
- 建议保留矢量源文件并导出 PDF/SVG；目前只有 PNG，后续修改公式、字号和术语时容易产生版本漂移。

## 无需改变的部分

- 输入保持为局部目标与三通道 terrain BEV，冻结实现不应重新加入未实际使用的 ego-history 分支。
- “训练期有界正则 + 推理期连续势梯度引导”的双路径结构正确。
- 速度、可靠航向、曲率和横向加速度从候选无噪轨迹估计诱导的逻辑正确。
- 势梯度在生成过程中持续作用，而非完成后过滤的核心信息流正确。

完成上述修改后，框架图即可与 `vtf_flow_methodology_en.tex` 和 `vtf_flow_methodology_zh.tex` 的冻结方法描述一致。
