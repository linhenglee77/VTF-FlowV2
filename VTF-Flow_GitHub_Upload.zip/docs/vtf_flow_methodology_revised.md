# 3 方法

## 3.1 问题定义与总体框架

非结构化越野环境通常缺少明确的车道拓扑、规则化道路边界和稳定的路径先验。同一局部场景中，车辆可能存在多条几何形态不同但均具有一定合理性的未来轨迹；与此同时，地表可通行程度、障碍物分布和高程变化会共同影响轨迹的通行代价，而且这种影响还会随候选轨迹所诱导的速度与运动方向发生变化。因此，越野轨迹规划不仅需要描述未来轨迹分布中的潜在多样性，还需要在生成过程中持续刻画候选轨迹与局部地形之间的相互作用。

本文提出 VTF-Flow（Vehicle-Conditioned Terrain Feasibility-Guided Flow Planning），将条件生成式轨迹规划与车辆状态相关的连续地形可行性建模统一在同一框架中。对于物理时刻 \(t\)，冻结实现的有效场景条件写为

\[
\mathcal S_t=\{\mathbf g_t,\mathbf M_t\},\qquad
\boldsymbol\tau_t=\{\mathbf p_{t+i}\}_{i=1}^{H},\quad
\mathbf p_{t+i}=(x_{t+i},y_{t+i},z_{t+i})\in\mathbb R^3,
\tag{1}
\]

其中，\(\mathbf g_t\) 为 planning-ego 坐标系中的局部目标点，\(\mathbf M_t\) 为局部三通道 terrain BEV，\(\boldsymbol\tau_t\) 为预测的未来轨迹。当前实现保留了历史状态编码接口，但冻结实验的数据适配器向该分支提供零占位，因此本文不将真实 ego history 作为已验证的条件输入。本文采用右手 planning-ego 坐标系，当前 ego pose 位于原点，\(x\) 轴指向车辆前方，\(y\) 轴指向左侧，\(z\) 轴指向上方。预测步数为 \(H=30\)，相邻 waypoint 的时间间隔为 \(0.5\,\mathrm{s}\)，对应总预测时域 \(15\,\mathrm{s}\)。

VTF-Flow 首先利用 goal-anchored Flow Matching 学习从基础高斯分布到未来轨迹分布的连续生成动力学；随后由 terrain BEV 与候选轨迹自身诱导的运动状态构建 vehicle-conditioned terrain feasibility field。训练阶段在预测的 clean trajectory estimate 上施加有界可行性正则，推理阶段则对未指数化的车辆状态相关地形代价求梯度，并将经过轨迹维平滑、尺度归一化和范数限制的梯度直接注入 Flow 动力学。由此，地形可行性不再仅作为轨迹生成后的有效性检查，而是以训练期软偏置和推理期在线修正两种方式参与生成过程。

VTF-Flow 的整体框架如图 1 所示。蓝色分支表示由目标点和 terrain BEV 条件化的生成主干，绿色分支表示车辆状态相关的连续地形可行性建模，红色分支表示训练目标，青色分支表示推理期可行性引导。训练与推理共享相同的地形表示和候选运动状态建模，但分别采用有界可行性分数与未指数化地形代价，以承担不同的优化作用。

> **图 1 插入位置：修订后的 VTF-Flow 方法框架图。**

**图 1 | VTF-Flow 总体框架。** 局部目标点和三通道 terrain BEV 构成冻结模型的有效场景条件。Goal-anchored Flow network 学习从高斯初始状态到未来轨迹分布的条件速度场。Terrain BEV 派生障碍、不可通行性、坡度、粗糙度和障碍邻近度代价，并与候选轨迹诱导的速度及可靠航向共同构成车辆状态相关的地形可行性表示。训练阶段使用有界分数 \(F_{\mathrm{VT}}\) 对 clean trajectory estimate 施加软正则；推理阶段对未指数化目标 \(J_{\mathrm{VT}}\) 求梯度，并将处理后的修正连续注入 Flow 动力学。图中的地形和轨迹示例来自同一 RELLIS-3D sequence 00004、frame 000812，仅用于说明方法流程，不表示定量比较。

需要强调的是，本文所定义的 feasibility score 不是经过标定的安全概率，也不存在统一的安全阈值。VTF-Flow 的目标不是在硬可行集合内求解具有形式化保证的轨迹，而是在数据驱动的轨迹先验与较低的车辆状态相关地形代价之间形成可控的软权衡。

## 3.2 数据来源与局部轨迹构建

实验采用 RELLIS-3D 数据集 [1]。该数据集面向非结构化越野场景，提供相机、LiDAR、语义标注和定位相关信息。本文使用其中的 Ouster LiDAR 点云、点级语义标签、位姿和标定信息构建局部 terrain BEV 与监督轨迹；未使用的传感器模态不作为规划器输入。为避免相邻帧泄漏，训练、验证和测试集合按完整序列划分，而不是随机划分单帧。

设当前与未来位姿分别为 \(\mathbf T_e^w(t)\) 和 \(\mathbf T_e^w(t+i)\)。未来轨迹通过相对位姿变换构造：

\[
\mathbf T_e^t(t+i)=\left(\mathbf T_e^w(t)\right)^{-1}\mathbf T_e^w(t+i),
\qquad
\mathbf p_{t+i}=\operatorname{trans}\!\left(\mathbf T_e^t(t+i)\right).
\tag{2}
\]

当前 pose 因而严格映射至 \((0,0,0)\)。Ouster LiDAR 数据通过已核验的传感器到 planning-ego 变换进行对齐。由 pose 构建的 ground-truth（GT）轨迹表示数据采集车辆的实际行驶记录，而不是理论最优轨迹或绝对安全轨迹。

## 3.3 Goal-anchored trajectory Flow Matching

### 3.3.1 场景条件编码

场景编码器分别处理局部目标点和三通道 terrain BEV。目标坐标进入目标编码器前按照 \((24,12,3)\,\mathrm m\) 逐坐标归一化，terrain BEV 由轻量卷积网络编码。编码器输出融合为 \(192\) 维场景特征 \(\mathbf h_c\)，并进一步拼接未归一化的三维目标位置：

\[
\mathbf c_t=[\mathbf h_c;\mathbf g_t]\in\mathbb R^{195}.
\tag{3}
\]

保留米制目标坐标使目标锚定输运能够直接在轨迹空间中构造，而不需要对生成结果执行后处理式终点替换。

### 3.3.2 条件 Flow Matching

使用 \(s\in[0,1]\) 表示生成过程中的 Flow time，以区别于物理场景时刻 \(t\)。记干净的 GT 未来轨迹为 \(\mathbf x_1=\boldsymbol\tau_t^{\mathrm{gt}}\)，基础随机状态为 \(\mathbf x_0\sim\mathcal N(\mathbf0,\mathbf I)\)。在线性概率路径上，

\[
\mathbf x_s=(1-s)\mathbf x_0+s\mathbf x_1,
\qquad
\mathbf u_s=\mathbf x_1-\mathbf x_0,
\qquad
\mathcal L_{\mathrm{FM}}
=\mathbb E\!\left[\left\|\mathbf v_\theta(\mathbf x_s,s,\mathbf c_t)-\mathbf u_s\right\|_2^2\right].
\tag{4}
\]

为显式引入局部目标方向，速度场采用 goal-anchored 参数化：

\[
\boldsymbol\mu_{\theta,i}(\mathbf c_t)
=\frac{i}{H}\mathbf g_t+\mathbf r_{\theta,i}(\mathbf c_t),
\qquad
\mathbf v_\theta
=\frac{\boldsymbol\mu_\theta-\mathbf x_s}{\max(1-s,\varepsilon)}
+\Delta\mathbf v_\theta(\mathbf x_s,s,\mathbf c_t),
\quad \varepsilon=0.05.
\tag{5}
\]

其中，第一项描述朝向目标参考轨迹的基础输运，\(\mathbf r_\theta\) 和 \(\Delta\mathbf v_\theta\) 分别表示由场景条件预测的空间残差和速度残差。该结构提供目标方向先验，但并不把最后一个 waypoint 硬性固定在目标位置。

为了在轨迹空间中计算地形可行性，根据当前 Flow state 和预测速度恢复 clean trajectory estimate：

\[
\widehat{\mathbf x}_1^{(s)}
=\mathbf x_s+(1-s)\mathbf v_\theta(\mathbf x_s,s,\mathbf c_t).
\tag{6}
\]

该估计保留在自动微分图中，使训练期可行性正则和推理期地形梯度均可通过速度网络传播。不同的高斯初始状态产生不同的候选轨迹，但候选之间的几何差异不被预设为语义上严格可分的行为模式。

## 3.4 Vehicle-conditioned terrain feasibility field

### 3.4.1 Planner-used terrain representation

规划器使用局部三通道 terrain BEV：

\[
\mathbf M_t=\{T,O,\bar Z\},
\tag{7}
\]

其中，\(T\) 为 traversable fraction，\(O\) 为 obstacle density，\(\bar Z\) 为 normalized mean height。点级语义类别、原始 elevation 和度量 clearance 可用于数据诊断与可视化，但不直接进入冻结规划器的 terrain field。

基础地形分量包括障碍代价 \(C_o=O\)、不可通行代价 \(C_{nt}=1-T\)、坡度代价 \(C_s\)、粗糙度代价 \(C_r\) 和障碍邻近度代理 \(C_d\)。其中，\(Z=4.5\bar Z\) 用于恢复所采用的高度尺度；\(C_s\) 由按栅格分辨率缩放的 \(3\times3\) Sobel 高度梯度构造，并以 \(0.35\) 为参考尺度；\(C_r\) 由 \(5\times5\) 邻域高度标准差构造，并以 \(0.25\,\mathrm m\) 为参考尺度；\(C_d\) 由 \(9\times9\) 最大池化作用于 \(O\) 得到。各分量均截断至 \([0,1]\)。最终基础地形代价与 terrain-only feasibility 为

\[
C_T
=\frac{2.0C_o+1.2C_{nt}+0.8C_s+0.6C_r+0.8C_d}{5.4},
\qquad
F_T=\exp(-3C_T).
\tag{8}
\]

所有分量均通过双线性插值在候选轨迹的平面位置 \((x,y)\) 上查询，地图边界采用 border padding。由于 \(\bar Z\) 表示栅格点云平均高度，而不是经过可靠地面分割得到的 ground-surface elevation，当前地形引导只使用其派生的坡度和粗糙度，不显式约束预测轨迹的 \(z\) 分量。

### 3.4.2 Candidate-induced motion conditioning

车辆状态由当前候选轨迹自身诱导。相邻平面 waypoint 的位移用于估计速度 \(v_i\)、切向航向 \(\psi_i\) 和航向可靠度 \(r_i^\psi\)。当局部位移较小时，Sigmoid 可靠度会连续减弱方向信息。沿可靠航向查询 \(0.5\,\mathrm s\) 前视位置，并将当前位置与前视位置的邻障代价融合为 \(C_{d,i}^{\mathrm{eff}}\)。车辆状态相关的附加代价与最终 feasibility score 定义为

\[
q(v_i)=\operatorname{clip}(v_i/3,0,2)^{1.5},
\qquad
\Delta C_{v,i}=q(v_i)\left(C_{s,i}+0.8C_{r,i}+C_{d,i}^{\mathrm{eff}}\right),
\qquad
F_{\mathrm{VT},i}=\exp[-(3C_{T,i}+\Delta C_{v,i})].
\tag{9}
\]

因此，同一地形位置在不同候选速度与可靠航向下可以具有不同的相对可行性。该状态只包含能够从候选轨迹稳定计算的平面速度与航向，不引入缺乏可靠观测支持的 pitch 或 roll。

## 3.5 Feasibility-informed training and guided sampling

### 3.5.1 训练期可行性正则

基础 Flow Matching 目标保持不变。在 clean trajectory estimate 上增加车辆状态相关的可行性正则：

\[
\mathcal L_{\mathrm{VT}}
=\frac{1}{BH}\sum_{b=1}^{B}\sum_{i=1}^{H}
\left[1-F_{\mathrm{VT}}(\widehat{\mathbf p}_{b,i}^{(s)})\right],
\qquad
\mathcal L=\mathcal L_{\mathrm{FM}}+\lambda_{\mathrm{VT}}\mathcal L_{\mathrm{VT}},
\quad \lambda_{\mathrm{VT}}=1.
\tag{10}
\]

指数形式使单点正则保持有界，从而降低极端 terrain cost 在训练早期压倒基础速度匹配目标的风险。该损失提供相对地形偏置，而不是将 GT 轨迹重新定义为绝对安全标签。最终配置不加入额外的轨迹平滑损失。

### 3.5.2 推理期结构保持型可行性引导

推理阶段使用未指数化的车辆状态相关地形代价，以保留局部代价变化的梯度信息：

\[
J_{\mathrm{VT}}(\widehat{\mathbf x}_1^{(s)})
=\frac1H\sum_{i=1}^{H}\left[C_T(\widehat{\mathbf p}_i^{(s)})
+\Delta C_v(\widehat{\mathbf p}_i^{(s)})\right],
\qquad
\mathbf G_s=\nabla_{\mathbf x_s}J_{\mathrm{VT}}.
\tag{11}
\]

梯度通过 \(\mathbf x_s\rightarrow\mathbf v_\theta\rightarrow\widehat{\mathbf x}_1^{(s)}\rightarrow J_{\mathrm{VT}}\) 的完整计算链传播。由于 waypoint-resolved 梯度可能包含局部高频变化，首先沿轨迹维使用核 \([0.25,0.50,0.25]\) 平滑，再进行逐候选 RMS normalization、低范数抑制和轨迹级 \(\ell_2\) 范数裁剪，得到 \(\bar{\mathbf G}_s\)。本文将这一处理称为 trajectory-coherence operator。“结构保持”仅表示该处理在经验上减少局部梯度振荡并限制异常更新，不构成曲率、动力学可执行性或稳定性的形式化保证。

最终生成动力学及 Euler 离散化为

\[
\frac{d\mathbf x}{ds}
=\mathbf v_\theta(\mathbf x_s,s,\mathbf c_t)-\eta(s)\bar{\mathbf G}_s,
\qquad
\mathbf x_{n+1}=\mathbf x_n+\frac1N
\left[\mathbf v_\theta(\mathbf x_n,s_n,\mathbf c_t)-0.2s_n\bar{\mathbf G}_{s_n}\right],
\quad s_n=\frac nN.
\tag{12}
\]

冻结配置采用 \(N=16\) 个 Euler steps 和 \(K=8\) 个并行高斯初始状态。引导强度 \(\eta(s)=0.2s\) 随 Flow time 线性增强；梯度裁剪上限为 \(4.0\)，低范数阈值为 \(10^{-7}\)。最终主方法不启用 trust region 或自适应触发。可行性修正是连续软引导，不构成硬碰撞约束，因此输出候选仍需通过统一评价指标报告其地形违规和代价。

## 3.6 算法流程与实现边界

### 算法 1：Feasibility-informed VTF-Flow training

```text
输入：按序列划分的训练场景、GT 轨迹、λVT
输出：Flow 参数 θ

1: repeat
2:     编码目标点与 terrain BEV，得到条件 c
3:     采样 x0 ~ N(0,I) 和 s ~ U(0,1)
4:     构造 xs=(1-s)x0+s x1 及目标速度 us=x1-x0
5:     预测 vθ(xs,s,c)，计算 LFM
6:     计算 clean trajectory estimate x̂1(s)
7:     从 x̂1(s) 估计速度、航向和航向可靠度
8:     查询 FVT，计算 LVT 与总损失 L
9:     反向传播并更新 θ
10: until 达到预设训练轮数
```

### 算法 2：Structure-preserving feasibility-guided sampling

```text
输入：场景条件、训练后的 vθ、候选数 K、Euler 步数 N
输出：K 条候选轨迹

1: 编码场景一次，并沿候选维复制条件
2: 并行采样 K 个高斯初始轨迹状态
3: for n=0,...,N-1 do
4:     计算 Flow velocity 与 clean trajectory estimate
5:     构造候选诱导的运动状态并计算 JVT
6:     求 G=∇x JVT
7:     执行轨迹维平滑、RMS normalization、低范数抑制和 L2 clipping
8:     使用 η(sn)=0.2sn 完成一个引导 Euler step
9: end for
10: 返回 K 条候选轨迹
```

模型输出形状为 \([B,K,H,3]\)。本文使用 ADE、FDE、minADE@K、minFDE@K、候选多样性、轨迹平滑度、地形代价、地形违规率和推理延迟评价生成质量与可行性。由于当前方法只在开放环轨迹空间中提供软可行性偏置，本文不将其解释为闭环安全保证或车辆动力学可执行性证明。

## 参考文献

[1] Jiang, P., Osteen, P. R., Wigness, M. B. & Saripalli, S. RELLIS-3D Dataset: Data, Benchmarks and Analysis. *2021 IEEE International Conference on Robotics and Automation*, 1110–1116 (2021). https://doi.org/10.1109/ICRA48506.2021.9561251

[2] Lipman, Y., Chen, R. T. Q., Ben-Hamu, H., Nickel, M. & Le, M. Flow Matching for Generative Modeling. *International Conference on Learning Representations* (2023). https://openreview.net/forum?id=PqvMRDCJT9t

