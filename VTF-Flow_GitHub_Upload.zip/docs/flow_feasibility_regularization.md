# Flow Matching 可行性正则化

## 目标函数

基础分布、插值路径、目标速度和 Flow Matching 均保持不变：

```text
x0 ~ N(0, I)
x_t = (1-t) x0 + t x1
u_t = x1 - x0
L_FM = mean ||v_theta(x_t,t,c) - u_t||^2
```

由线性路径得到可微 clean endpoint 估计：

```text
x1_hat = x_t + (1-t) v_theta(x_t,t,c)
L_fea = mean[1 - F(x1_hat_i, vehicle_state_i)]
L = L_FM + lambda_fea L_fea + lambda_smooth L_smooth
```

`L_smooth` 是轨迹二阶有限差分的平均 L2 模长，独立于地形场；默认权重为 0，当前敏感性实验没有用它混入 F。

## 两类可行性训练

- `terrain`：在缓存的三通道 BEV 上构建 `AnalyticTerrainField`，双线性查询连续地形可行性。
- `vehicle`：在相同地形场上加入由轨迹差分得到的 speed、heading 和软 heading reliability。坡度、粗糙度及邻障代价随连续速度响应增强。

训练缓存没有米制欧氏 clearance map，所以 vehicle 版本的 clearance 是局部 occupancy proximity 代理，并带 heading look-ahead。需要米制 clearance 的最终评估仍应从原始 LiDAR 构建连续场，不能把代理值解释为真实安全距离。

## 指标口径

- `minADE@K`、`minFDE@K`：对每个场景取 oracle best candidate，再跨场景平均。
- terrain violation：occupancy 或 non-traversable 分量超过配置阈值的 waypoint 比例，跨所有场景和候选平均。
- mean terrain cost、vehicle-conditioned cost：跨所有场景、候选和 waypoint 平均。
- slope violation：归一化 slope 分量超过配置阈值的比例。
- smoothness：跨所有候选的二阶有限差分模长均值。
- latency：包含 K 个候选、配置 ODE 步数的一次 planner 调用耗时，换算为每场景毫秒。

这些违规率是研究诊断指标，不是安全认证阈值；尤其不使用 `F < 0.5` 判定安全或危险。

## 运行

```powershell
python scripts/run_flow_feasibility_experiment.py `
  --cache-root <RELLIS3D_TRAJECTORY_CACHE>
```

输入数据路径只由命令行给出。聚合结果、每次运行的 effective config、epoch 日志、checkpoint 和 JSON 指标均保存到 `outputs/experiments/flow_feasibility/`。
