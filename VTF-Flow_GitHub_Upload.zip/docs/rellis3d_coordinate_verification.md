# RELLIS-3D LiDAR 到 planning-ego 坐标核验

## 结论与适用边界

VTF-Flow 采用以下 Ouster LiDAR 到规划坐标的变换：

```text
T_planning_ego_os1_lidar = diag(-1, -1, 1, 1)
```

即绕 z 轴旋转 180°，不加平移。planning-ego 的轴与 RELLIS Warthog
`base_link` 对齐（x 前、y 左、z 上），原点仍保留在当前 Ouster LiDAR
扫描原点。这与现有 GT 轨迹缓存的构造完全一致，因此当前时刻仍严格映射到
`(0,0,0)`。

这不是在声称 LiDAR 与车辆底盘中心重合。校准 bag 中恢复出的完整安装变换约为：

```text
T_base_link_os1_lidar =
[[-1,  0, 0, 0.190000008],
 [ 0, -1, 0, 0.000000024],
 [ 0,  0, 1, 0.848359976],
 [ 0,  0, 0, 1]]
```

若未来把轨迹原点改成底盘中心，必须对完整相对姿态做外参共轭变换，不能只给
轨迹平移加一个固定偏置。

## 本地证据链

1. 三个本地官方归档均命名为 `Rellis_3D_lidar_poses*`，且官方
   [RELLIS-3D 仓库](https://github.com/unmannedlab/RELLIS-3D)把
   `poses.txt` 描述为每个 scan 的 pose。Ouster 帧、pose 行和 RGB 帧的索引集合
   在五个序列中一一对应。
2. 无 ROS 依赖解析本地校准 bag 的 `/tf` 和 `/tf_static` 后，得到
   `base_link → chassis_link → top_chassis_link → imu_link → os1_frame →
   ouster1/os1_sensor → ouster1/os1_lidar` 链。组合后的旋转为约
   `Rz(180°)`，安装位置约 `(0.19, 0, 0.84836)m`。
3. 原始 pose 的连续运动主要沿 `-x`。应用 `diag(-1,-1,1)` 后，运动帧中
   `+x` 前进比例在序列 00000–00004 分别为 99.92%、99.61%、98.79%、
   99.79%、99.84%，且最大相邻位移均小于 0.30 m。
4. 已生成轨迹缓存的 `dataset_config.json` 声明 x 前、y 左、z 上，其构建器使用
   同一 180° z 轴基变换。变换后的 GT 与点云前向网格重合；identity 会把二者
   放到相反的 x 半轴。

可复现工具与产物：

- `scripts/inspect_rellis3d_tf.py`：只读 ROSBAG v2 TF 解析器；
- `outputs/experiments/rellis3d_tf_audit.json`：解析出的 TF 边；
- `configs/rellis3d_os1_to_planning_ego.json`：验证所用矩阵及完整安装矩阵；
- `datasets/trajectory_builder.py::rellis3d_os1_to_planning_ego`：统一 pose
  约定适配边界。

## 仍需保留的校准不确定性

校准 bag 对 `ouster1/os1_sensor → ouster1/os1_lidar` 同时包含 identity 与
180° yaw 两个静态记录，bag 连接头未保存可用于区分发布者的 caller ID。VTF-Flow
选择 180° 记录，因为它与完整 TF 链、五序列运动方向及既有轨迹缓存三项独立证据
一致。因而本项目内部的 planning-ego 对齐已经可复现地确认，但该结论不替代测量级
外参复标，也不应扩展为安全认证。
