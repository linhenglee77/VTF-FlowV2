# VTF-Flow design specification

## Coordinates and shapes

- Ego-centric right-handed planning frame: `x` forward, `y` left, `z` up.
- The current ego pose is `(0, 0, 0)` with heading aligned to positive `x`.
- Future trajectories use `[B, K, H, 3]`; RELLIS-3D defaults to `H=30`,
  `dt=0.5 s`, covering 15 s because the existing cache uses every fifth pose
  from a nominal 10 Hz sequence.
- BEV maps use `[B, 3, 64, 64]` over forward `0–24 m` and lateral `−12–12 m`.
  Channels are traversable fraction, obstacle density and normalized elevation.

## Core public interfaces

`SceneBatch` carries ego history, GT future, local goal, optional raw sensor data,
terrain map and metadata. `TrajectoryBatch` carries `[B,K,H,D]` predictions and
optional deployment scores. `BasePlanner`, `BaseTerrainField` and `Evaluator`
remain stable extension points.

## Flow representation

The clean state is a standardized residual from linear interpolation to the local
goal. This makes the final residual zero while retaining multimodal intermediate
paths. Training uses linear conditional Flow Matching:

`x_t=(1−t)x_0+t x_1`, `u_t=x_1−x_0`, and `L=mean||v_theta−u_t||²`.

Inference uses Euler integration. Feasibility guidance modifies the vector field:

`dx/dt = v_theta(x,t,c) − eta(t) normalized_gradient(J_feasibility)`.

The default `J` reports terrain, smoothness, curvature and steering-rate terms
separately. Vehicle conditioning uses waypoint speed to increase slope,
roughness and clearance costs analytically.

## Module responsibilities

- `datasets`: adapt audited RELLIS-3D cache to common scenes;
- `models`: encode scene and predict Flow velocity;
- `terrain`: construct and query continuous analytic fields;
- `guidance`: differentiate feasibility objectives during ODE integration;
- `planners`: integrate Flow and return multimodal trajectories;
- `metrics/evaluation`: compute trajectory, terrain and vehicle metrics;
- `scripts`: train and evaluate without hard-coded dataset paths.

Yaw, speed and control sequences can later be added as extra trajectory channels.
The public trajectory tensor keeps its final dimension generic for this reason.
