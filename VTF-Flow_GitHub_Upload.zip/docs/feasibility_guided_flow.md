# Feasibility-Guided Flow Sampling

## 方法

Baseline Flow 的训练目标和 Euler solver 均未改变。每一步从当前状态计算 `x1_hat = x_t + (1-t) v_theta`，仅以 vehicle-conditioned terrain cost 为 J，通过完整 `x_t -> v_theta -> x1_hat -> J` 计算梯度，再执行 `dx/dt = v_theta - eta(t) grad_x J`。没有加入 RL、曲率、平滑、goal 或额外 occupancy guidance。

## A/B/C/D 汇总

| Variant | minADE@K | minFDE@K | terrain violation | terrain cost | vehicle cost | slope violation | smoothness | diversity | latency ms/scene |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Flow | 0.4541 | 0.0435 | 0.4218 | 0.3115 | 0.6911 | 0.2904 | 0.0175 | 0.1479 | 0.436 |
| Flow + Feasibility Training | 0.4508 | 0.0334 | 0.4163 | 0.3084 | 0.6819 | 0.2928 | 0.0168 | 0.1551 | 0.310 |
| Flow + Feasibility Guidance | 0.4624 | 0.0493 | 0.4132 | 0.3018 | 0.6692 | 0.2837 | 0.0279 | 0.1381 | 3.842 |
| Full Model | 0.4650 | 0.0407 | 0.4090 | 0.2990 | 0.6611 | 0.2873 | 0.0282 | 0.1398 | 3.839 |

## 十个问题的回答

1. **推理 guidance 是否降低 cost？** 是。C 相对 A 的 vehicle cost 变化 -0.0219，terrain cost 变化 -0.0097。
2. **是否比只做训练正则更有效？** 若只看 feasibility，C 比 B 更有效，vehicle cost 低 0.0127；但 minADE 高 0.0117 m，因此综合质量上不能无条件说更好。
3. **训练+guidance 是否还有收益？** 有额外 feasibility 收益：D 相对 B 的 vehicle cost 低 0.0208，相对 C 低 0.0081；但 D 的 minADE/smoothness 相对 B 均变差，所以仍是 trade-off。
4. **推荐 eta 范围？** 当前保守范围是 0.05–0.20。按 minADE 不超过 baseline 5%、smoothness 不超过 baseline 20%，再最小化 vehicle cost 的预声明规则，选择 eta=0.2。
5. **late-strong 是否更好？** 不是普遍更好。eta=0.5 下最低 vehicle cost 是 constant，但按与 eta sweep 相同的 fidelity/smoothness guardrail，可接受折中为 early-strong；late-strong 位于两者之间。
6. **生成过程中是否渐进降低？** 总体是。eta=0.5 late-strong 从 step 0 到最后记录点下降 0.0145；早期小幅上升、后期下降且末步回弹，并非严格单调。
7. **哪些指标变差？** 相对 A，C 的 minADE 变化 +0.0083 m，minFDE 变化 +0.0058 m，smoothness 变化 +0.0104 m，diversity 变化 -0.0098 m。
8. **额外延迟？** C 相对 A 为 +3.405 ms/scene；D 相对 B 为 +3.529 ms/scene。
9. **是否存在失败案例？** 存在；定性案例按最大 paired minADE 恶化客观选取，不是只展示成功案例。
10. **是否证明 feasibility 进入生成动力学？** eta=0 最大差异为 0，非零 eta 改变同初始噪声轨迹且逐步记录到梯度/cost 演化，因此足以支持当前实现层面的“in-flow dynamics”机制主张；但单种子、单验证序列不足以支持统计稳健性或通用安全性主张。

## 限制

缓存 BEV 的 clearance 是 occupancy proximity 代理，不是米制欧氏安全距离；所有 violation 都是当前相对诊断口径，没有把 F<0.5 当作通用安全阈值。当前只有一个 seed 和验证序列 00004。
