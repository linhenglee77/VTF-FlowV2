# Structure-Preserving Feasibility-Guided Flow

训练好的 Flow、Euler solver、初始高斯噪声、验证序列和 vehicle-conditioned field 均保持不变。本实验只修改推理期 feasibility correction。

## 主对照（eta=0.2，rho=0.2）

| Method | minADE@K | vehicle cost | terrain violation | smoothness | max local 2nd diff | mean correction | max correction | diversity | latency ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Unguided | 0.4541 | 0.6911 | 0.4218 | 0.0175 | 0.0441 | 0.0000 | 0.0000 | 0.1479 | 0.367 |
| Raw | 0.4550 | 0.6813 | 0.4179 | 0.0194 | 0.0465 | 0.0446 | 0.1126 | 0.1440 | 4.188 |
| Smoothed | 0.4550 | 0.6814 | 0.4181 | 0.0177 | 0.0446 | 0.0444 | 0.1114 | 0.1440 | 4.253 |
| Trust region | 0.4550 | 0.6813 | 0.4179 | 0.0194 | 0.0465 | 0.0446 | 0.1126 | 0.1440 | 3.952 |
| Smooth + trust | 0.4550 | 0.6814 | 0.4181 | 0.0177 | 0.0446 | 0.0444 | 0.1114 | 0.1440 | 4.099 |
| Adaptive | 0.4541 | 0.6897 | 0.4215 | 0.0175 | 0.0442 | 0.0053 | 0.0141 | 0.1473 | 4.151 |

## 十个问题

1. **Raw guidance 为什么破坏 smoothness？** waypoint cost gradient 含沿 H 的高频分量；raw 在归一化后每步施加 correction，smoothness 相对 unguided 变化 +0.0018 m，最大局部二阶差分变化 +0.0024 m。
2. **平滑是否减少局部畸变？** Smoothed 相对 Raw 的 smoothness 变化 -0.0017 m，最大局部二阶差分变化 -0.0019 m。
3. **Trust region 是否阻止 correction 主导 Flow？** Raw 平均 correction/Flow 比为 0.0072，Smooth+Trust 为 0.0072；主配置的逐步最大比约为 0.065，小于 rho=0.2，trust region 未触发。因此它只是高强度 guidance 的保护上界，不能解释本次改善。
4. **组合方法是否改善 trade-off？** Smooth+Trust 相对 Raw 的 vehicle cost 差值 +0.0001，minADE 差值 +0.0000 m，smoothness 差值 -0.0017 m。
5. **Adaptive trigger 是否有用？** J_ref=0.9779 仅来自训练 GT 75 分位，不是安全阈值。Adaptive 相对组合方法的 vehicle cost/minADE/smoothness 差值依次为 +0.0083/-0.0009/-0.0001。
6. **实际 correction 多大？** 保留候选方法平均 waypoint correction 为 0.0444 m，endpoint correction 为 0.0168 m。
7. **何时与 Flow 冲突？** Raw 的平均 cos(Flow, gradient)=-0.0232；逐步符号和变化见 flow_step_diagnostics.csv，正值意味着减去 gradient 会抵消部分 Flow 速度。
8. **是否保持 diversity？** 保留候选方法相对 unguided 的 diversity 变化 -0.0039 m。
9. **额外延迟？** 保留候选相对 unguided 增加 +3.886 ms/scene。
10. **最终保留哪个设计？** 当前保留 `Smoothed (kernel=3, eta=0.2)`：它取得与组合方法相同的结果，但无需一个在主配置下未触发的约束。Trust region 仍作为更强 guidance 时的可选保护机制；这不是通用最优性声明。

## 失败案例与证据边界

复用了 dataset index 6172；同时按确定性规则选择最佳 feasibility、最差 fidelity 和最佳折中案例。最佳折中规则为：maximum feasibility gain under per-scene 1% minADE and 5% smoothness limits。
当前仍为单 seed、单验证序列；clearance 是缓存 BEV 邻障代理，J_ref 和所有 violation 均不是校准安全阈值。
