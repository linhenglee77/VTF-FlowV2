# VTF-Flow Final Experimental Validation

## 执行协议

采用 reduced sequence-disjoint protocol，而非完整 LOSO：主协议 train=00000/00001/00002、validation=00003、test=00004，使用 seeds 0/1/2；附加 swapped 协议 train=00000/00001/00004、validation=00002、test=00003，使用 seed 0。缓存的 train/val/test 目录先合并，再按 sequence 重分区；不存在随机帧泄漏。

所有显著性检验先在每个场景上对三个 seed 取平均，再进行双侧 Wilcoxon signed-rank；效应量为 matched-pairs rank-biserial correlation，全部检验统一使用 Benjamini–Hochberg FDR。95% CI 由场景级 1000 次 bootstrap 得到。Violation 是诊断比例，不是校准安全率。

## 主结果（主协议，mean ± sample SD across 3 seeds）

| Method | minADE@K_m | minFDE@K_m | mean_vehicle_conditioned_cost | terrain_violation_rate | smoothness_m | diversity_m | latency_ms_per_scene |
|---|---|---|---|---|---|---|---|
| Regression | 0.5824 ± 0.0121 | 0.0000 ± 0.0000 | 0.6796 ± 0.0061 | 0.4384 ± 0.0078 | 0.0124 ± 0.0019 | 0.0000 ± 0.0000 | 0.0173 ± 0.0007 |
| Flow | 0.5313 ± 0.0385 | 0.0538 ± 0.0342 | 0.6845 ± 0.0066 | 0.4283 ± 0.0048 | 0.0225 ± 0.0045 | 0.1892 ± 0.0461 | 0.1561 ± 0.0009 |
| Flow + Feasibility Training | 0.5127 ± 0.0480 | 0.0469 ± 0.0333 | 0.6852 ± 0.0046 | 0.4304 ± 0.0039 | 0.0212 ± 0.0022 | 0.2303 ± 0.0286 | 0.1570 ± 0.0011 |
| Flow + Smoothed Guidance | 0.5315 ± 0.0365 | 0.0549 ± 0.0346 | 0.6766 ± 0.0044 | 0.4240 ± 0.0039 | 0.0226 ± 0.0046 | 0.1845 ± 0.0441 | 2.2932 ± 0.0099 |
| VTF-Flow | 0.5114 ± 0.0451 | 0.0469 ± 0.0317 | 0.6756 ± 0.0042 | 0.4254 ± 0.0045 | 0.0213 ± 0.0022 | 0.2234 ± 0.0255 | 2.2869 ± 0.0120 |

## 十二个问题

1. **Flow 是否优于 Regression？** Flow minADE=0.5313，Regression=0.5824，即 best-of-K 改善 8.8%。但 Regression 的 goal-anchor 结构强制终点等于输入 goal，因此 minFDE=0；Flow minFDE=0.0538。故证据支持 best-of-K 轨迹形状优势，不支持“Flow 在所有精度指标全面优于 Regression”。
2. **Feasibility training 是否改善 learned distribution？** 若按 feasibility 本身回答，则否：B-A vehicle cost=+0.0007，且该小幅恶化经 FDR 后显著；但 B-A minADE=-0.0186 m、smoothness=-0.0013 m，说明训练正则主要改善了当前样本的 accuracy/structure，而未单独改善 field cost。
3. **Inference guidance 是否提供额外收益？** C-A vehicle cost=-0.0078；D-B=-0.0096。
4. **Smoothed 是否比 Raw 更保持结构？** feasibility gain retained=101.2%，excess smoothness loss removed=92.9%。
5. **VTF-Flow 是否达到有意义折中？** 在主 test=00004 上是：D-A vehicle cost=-0.0089，minADE=-0.0199 m，smoothness=-0.0012 m，三者均经 FDR 后显著；但 swapped test=00003 的 minADE 恶化约 0.0099 m，因此不能把主序列折中泛化为所有地形。
6. **统计显著性？** 25/28 个预先列出的检验在 BH-FDR 0.05 下显著；A-D vehicle cost 的 adjusted p=2.09e-176，rank-biserial=-0.750。
7. **跨序列一致吗？** vehicle cost 在 test=00004 与 test=00003 均改善，但 minADE 只在 00004 改善、在 00003 恶化。主协议有 3 seeds，swapped 只有 1 seed；因此 feasibility 方向是一致趋势，fidelity 不是，更不能声称五序列 LOSO 泛化。
8. **eta 敏感性？** 在 minADE≤baseline×1.01 且 smoothness≤baseline×1.05 的预声明 guardrail 下，观察到的最低 vehicle cost 对应 eta=0.2；这不是普遍最优。
9. **sampling steps 敏感性？** 4/16/32 步 latency 分别为 0.584/2.372/4.622 ms；32 步 minADE 略低但 smoothness 明显升至 0.0513。Euler-16 是冻结主设置，不是所有指标上的最优步数。
10. **K 是否有用？** K=1 到 K=10 的 minADE 变化 -0.1584 m，diversity 变化 +0.2356 m。
11. **主要失败模式？** both_degraded=146, both_improved=988, feasibility_improved_fidelity_degraded=543, fidelity_improved_feasibility_degraded=232。
12. **支持与不支持的主张？** 支持项必须同时满足多 seed 方向、场景配对效应和 FDR/CI 证据。不支持校准安全性、完整 LOSO 泛化、eta=0.2 普遍最优，以及 binary<terrain<vehicle 的先验排序。本次 field cost 排序为：vehicle_continuous < terrain_continuous < binary（仅限当前设置）。

## 证据边界

- 只有主协议具备三个独立训练 seed；swapped split 是单 seed 稳健性检查。
- clearance 来自缓存 BEV 的邻障代理，不是原始 LiDAR 上的认证欧氏净空。
- Binary traversability 不可微，因此其 guidance 对照等价于 unguided Flow；这说明其不适合作为梯度场，  但不能单独证明连续表示在所有规划器上更优。
- 所有 qualitative cases 按保存的数值规则自动选取，没有人工 cherry-pick。

## 结论分级

### 统计支持

- 主 test=00004 上，VTF-Flow 相对 Flow 的 vehicle cost、minADE 与 smoothness 均改善，95% CI、配对 Wilcoxon 和 BH-FDR 方向一致。
- Smoothed inference guidance 对 baseline/VC-trained checkpoint 都带来额外 vehicle-cost 改善。
- K 增大带来明显 best-of-K 精度收益，支持当前数据上的多模态候选价值。

### 趋势

- feasibility 改善在两个 held-out sequence 方向一致，但 swapped split 只有一个 seed。
- 连续 terrain/vehicle fields 均优于 binary 对照的 vehicle cost，但 terrain violation 与 vehicle cost 的最优表示不同。

### 未解决限制

- 未执行完整五折 LOSO；没有校准安全阈值或真实米制 clearance；不能声称 eta=0.2 普遍最优。
- Feasibility training 单独并未降低 field cost，其与 guidance 的互补机制仍需更多序列和 seed 验证。
