# Prompt implementation coverage

| Prompt | Status | Reused or implemented module |
|---|---|---|
| 1 project/interfaces | Implemented | `TerraFlow/interfaces.py`, package structure |
| 2 data audit | Already available | root `scripts/audit_rellis3d.py` and audit outputs |
| 3 pose to GT | Already available | root `datasets/trajectory_builder.py` and GT figures |
| 4 evaluator | Implemented/reused | `TerraFlow/metrics`, `TerraFlow/evaluation` |
| 5 baselines | Already available but not yet refactored | unified Hybrid A*/MPPI/CEM comparison |
| 6 regression | Not implemented in this increment | next baseline task |
| 7 minimal Flow Matching | Implemented | Flow network, planner and training script |
| 8 regression vs Flow | Pending regression baseline | evaluation interface is ready; Flow is trained |
| 9 terrain field | Implemented | analytic continuous 2.5D field |
| 10 vehicle-conditioned field | Implemented | learned base/speed heads plus current speed, tangent heading, vehicle-width clearance, longitudinal grade and cross slope |
| 11 feasibility training | Implemented | geometry-only learned field; target-like traversability channel excluded after leakage audit |
| 12 guided Flow sampling | Implemented and evaluated | normalized gradient/time schedule; 512 paired test scenes |
| 13 kinematic constraint | Reused/implemented | curvature and steering-rate guidance/metrics |
| 14 full ablation | Implemented for inference mechanisms | five-seed paired unguided/filter/refine/guided/guided-no-rerank rolling comparison; training-time guidance remains future work |

This increment intentionally compares unguided Flow with sampling-guided Flow
before adding feasibility training, so the causal contribution of inference-time
guidance remains identifiable.

The current rolling run uses five trained Flow seeds, eight candidates, sixteen
Euler steps, paired initial noise, 0.5 s replanning and 0.1 s bicycle control.
The learned field excludes the target-like traversability input after an explicit
leakage audit. Exact results are stored under
`outputs/terraflow_receding_horizon_5seed_geometry_field`.

The strict mechanism audit is stored under
`outputs/terraflow_guidance_mechanism_5seed_v2`. It records the feasibility
objective at every Flow and refinement step and shows that filtering leaves the
generated candidates unchanged, whereas in-Flow guidance improves 99.96% of
paired candidates before terminal selection.
