# 3 方法

## 3.1 问题定义与总体框架

非结构化越野环境通常缺少明确的车道拓扑、规则化道路边界和稳定路径先验。同一局部场景中，车辆可能存在多条几何形态不同但均具有一定合理性的未来轨迹；与此同时，地形语义、高程起伏、局部坡度、表面粗糙度及障碍物分布会共同影响轨迹的可执行性，而且这种影响还会随车辆速度和运动方向发生变化。因此，越野轨迹规划不仅需要刻画未来运动的不确定性，还需要在生成过程中持续感知候选轨迹与局部地形之间的相互作用。

本文提出 **VTF-Flow**（Vehicle-conditioned Terrain Feasibility-guided Flow），将多模态轨迹生成与车辆状态相关的连续地形可行性建模统一在同一框架中。给定场景观测

\[
\mathcal S_t=\{\mathbf H_t,\mathbf g_t,\mathbf M_t\},\qquad
\boldsymbol\tau_t=\{\mathbf p_{t+i}\}_{i=1}^{H},\quad \mathbf p_{t+i}\in\mathbb R^3,
\]

其中，\(\mathbf H_t\) 为历史自车状态，\(\mathbf g_t\) 为局部目标点，\(\mathbf M_t\) 为由 LiDAR 构建的局部地形表示；模型输出 \(K\) 条自车坐标系下的未来轨迹。VTF-Flow 首先利用条件 Flow Matching 学习从高斯噪声到未来轨迹分布的连续动力学，再利用车辆状态相关的地形可行场，在训练阶段约束预测的清洁轨迹，在推理阶段通过经过时间平滑和尺度归一化的可行性梯度修正生成动力学。

该框架的核心不是在轨迹生成完成后进行一次二值有效性检查，而是将地形可行性作为连续、可微且与候选运动状态相关的相对代价嵌入轨迹生成过程。本文所使用的可行性值并非安全概率，也不对应固定安全阈值；其用途是为候选轨迹之间的相对比较和局部梯度引导提供一致信号。

## 3.2 数据来源与局部轨迹构建

实验采用 RELLIS-3D 数据集 [1]。该数据集面向非结构化越野场景，提供相机、LiDAR、语义标注及定位相关传感器数据；原始论文报告了 13,556 帧带标注的 LiDAR 扫描和 6,235 帧带标注的图像。本文实际使用其中的 LiDAR 点云、点级语义标签、位姿和标定信息构建局部地形与监督轨迹，不将未使用的传感器模态作为模型输入。为避免相邻帧泄漏，训练、验证和测试数据按序列划分，而不是随机划分单帧。

设数据记录的当前位姿和未来位姿分别为 \(\mathbf T^{w}_{e}(t)\) 与 \(\mathbf T^{w}_{e}(t+i)\)。未来位姿首先被转换到当前自车坐标系：

\[
\mathbf T^{t}_{e}(t+i)=\left(\mathbf T^{w}_{e}(t)\right)^{-1}\mathbf T^{w}_{e}(t+i),
\qquad
\mathbf p_{t+i}=\operatorname{trans}\!\left(\mathbf T^{t}_{e}(t+i)\right).
\]

当前自车位姿由此严格映射到原点。本文采用右手自车坐标系，\(x\) 轴指向车辆前方，\(y\) 轴指向左侧，\(z\) 轴指向上方；LiDAR 数据通过已核验的传感器到规划自车坐标变换进行对齐。默认预测时域为 \(15\,\mathrm{s}\)，采样间隔为 \(0.5\,\mathrm{s}\)，因此 \(H=30\)。由位姿得到的轨迹表示数据采集车辆的实际行驶记录，而不是理论最优轨迹或绝对安全轨迹。

## 3.3 条件轨迹 Flow Matching

场景编码器分别处理历史轨迹、目标点和局部地形。历史轨迹与目标点在进入编码器前按固定空间尺度归一化；地形分支使用轻量卷积网络提取鸟瞰图特征。各分支输出拼接后形成条件向量 \(\mathbf c\)。最终实现中，场景嵌入维数为 192，并额外拼接未归一化的三维目标点，因此 \(\mathbf c\in\mathbb R^{195}\)。

依据 Flow Matching [2]，令清洁轨迹为 \(\mathbf x_1\in\mathbb R^{H\times3}\)，基础样本为 \(\mathbf x_0\sim\mathcal N(\mathbf0,\mathbf I)\)，并采用线性概率路径：

\[
\mathbf x_t=(1-t)\mathbf x_0+t\mathbf x_1,\qquad
\mathbf u_t=\mathbf x_1-\mathbf x_0,
\qquad
\mathcal L_{\mathrm{FM}}=\mathbb E\bigl[\|\mathbf v_\theta(\mathbf x_t,t,\mathbf c)-\mathbf u_t\|_2^2\bigr].
\]

为显式保留目标方向先验，速度网络采用目标锚定参数化。条件均值由目标点的线性插值与可学习残差组成，网络再预测相对于该均值动力学的速度残差：

\[
\boldsymbol\mu_{\theta,i}(\mathbf c)=\frac{i}{H}\mathbf g+\mathbf r_{\theta,i}(\mathbf c),qquad
\mathbf v_\theta=\frac{\boldsymbol\mu_\theta-\mathbf x_t}{\max(1-t,\varepsilon_t)}+\Delta\mathbf v_\theta,\quad \varepsilon_t=0.05.
\]

训练期间，根据当前中间状态估计对应的清洁轨迹

\[
\widehat{\mathbf x}_1=\mathbf x_t+(1-t)\mathbf v_\theta(\mathbf x_t,t,\mathbf c),
\]

并在 \(\widehat{\mathbf x}_1\) 上计算地形可行性损失。推理时，从不同的高斯初始状态出发，数值积分同一速度场即可产生多个候选轨迹。该采样机制支持几何上不同的候选解，但几何差异本身不等价于已经验证的语义或拓扑绕行模式。

## 3.4 车辆状态相关的连续地形可行场

### 3.4.1 局部地形表示

规划器使用由局部 LiDAR 缓存构建的三通道鸟瞰图：可通行点比例 \(T\)、障碍点密度 \(O\) 和归一化平均高度 \(\bar Z\)。与包含离散语义类别和度量净空的高成本诊断地形图不同，该缓存表示可由训练批次直接加载，并保持端到端查询的可微性。本文将 \(\bar Z\) 恢复为近似米制高程 \(Z=4.5\bar Z\)，从中计算局部坡度和粗糙度；同时由障碍密度的局部最大池化构建障碍接近度代理。由此得到障碍、不可通行性、坡度、粗糙度和接近度五个分量，分别记为 \(C_o,C_{nt},C_s,C_r,C_d\)。

地形基础代价及其连续可行性定义为

\[
C_T=\frac{2.0C_o+1.2C_{nt}+0.8C_s+0.6C_r+0.8C_d}{5.4},qquad
F_T=\exp(-3C_T).
\]

其中，坡度由尺度校正的 Sobel 高程梯度估计，参考尺度为 0.35；粗糙度由 \(5\times5\) 邻域内的高度标准差估计，参考尺度为 \(0.25\,\mathrm m\)；障碍接近度使用 \(9\times9\) 邻域最大池化近似。所有轨迹点均通过双线性插值查询连续场，边界外查询采用边界复制，以避免不受控的外推梯度。由于当前缓存不包含可可靠恢复的点级地面高程，地形引导仅作用于 \((x,y)\) 平面，不对轨迹 \(z\) 分量施加伪造的高程一致性约束。

### 3.4.2 候选运动状态条件化

车辆状态直接从候选轨迹的相邻平面位移中估计，包括速度 \(v_i\) 和航向 \(\psi_i\)。当位移过小时，航向估计不稳定，因此使用由位移长度控制的连续可靠度权重，在当前位置接近度与沿航向前视位置接近度之间进行软融合。速度响应采用平滑幂函数，并分别增强坡度、粗糙度和障碍接近度代价。该过程可紧凑写为

\[
q(v)=\operatorname{clip}(v/3,0,2)^{1.5},\qquad
\Delta C_v=q(v)\bigl(1.0C_s+0.8C_r+1.0C_d^{\mathrm{eff}}\bigr),qquad
F_{VT}=\exp[-(3C_T+\Delta C_v)].
\]

其中，\(C_d^{\mathrm{eff}}\) 同时考虑当前点和 \(0.5\,\mathrm{s}\) 前视位置的障碍接近度；航向可靠度由位移长度的 Sigmoid 函数连续调节。由此，同一地形位置在不同候选速度和航向下可获得不同的相对可行性。该模型仅包含能够由候选轨迹稳定计算的平面速度和航向，不引入缺乏可靠观测支持的俯仰角或侧倾角。

## 3.5 可行性感知训练与结构保持型引导

### 3.5.1 训练目标

在不改变基础 Flow Matching 目标的前提下，本文在预测的清洁轨迹上增加车辆状态相关的可行性正则项：

\[
\mathcal L_{VT}=\frac{1}{BH}\sum_{b=1}^{B}\sum_{i=1}^{H}\bigl[1-F_{VT}(\widehat{\mathbf p}_{b,i})\bigr],qquad
\mathcal L=\mathcal L_{\mathrm{FM}}+\lambda_{VT}\mathcal L_{VT}.
\]

最终模型采用 \(\lambda_{VT}=1.0\)。指数映射将训练正则限制在有限范围内，从而避免极端地形代价在训练早期压倒 Flow Matching 主目标。训练损失只提供相对地形偏置，不把示范轨迹重新定义为绝对安全标签。

### 3.5.2 推理阶段的结构保持型可行性引导

推理时，在每个积分时刻先由当前流状态获得清洁轨迹估计，再计算未指数化的车辆状态相关代价

\[
J_{VT}=\frac{1}{H}\sum_{i=1}^{H}\bigl(C_T(\widehat{\mathbf p}_i)+\Delta C_v(\widehat{\mathbf p}_i)\bigr),qquad
\mathbf g_t=\nabla_{\mathbf x_t}J_{VT}.
\]

与训练阶段使用有界可行性分数不同，推理阶段直接对代价求梯度，以降低指数映射在低可行区域造成的梯度衰减。两者共享同一地形能量与车辆状态建模，但承担不同的优化角色。

原始梯度可能沿时间维高频振荡或出现局部异常幅值。为此，本文依次采用核 \([0.25,0.5,0.25]\) 的轨迹时间平滑、逐候选均方根归一化、低范数抑制和 \(\ell_2\) 范数裁剪，得到处理后的梯度 \(\bar{\mathbf g}_t\)。最终生成动力学为

\[
\frac{d\mathbf x}{dt}=\mathbf v_\theta(\mathbf x,t,\mathbf c)-\eta(t)\bar{\mathbf g}_t,qquad
\eta(t)=\eta_0t^\gamma,\quad \eta_0=0.2,\ \gamma=1.
\]

该设计使引导在生成后期逐渐增强：早期主要保留 Flow 模型的全局分布演化，后期再对已经形成的轨迹结构进行局部地形修正。本文将其称为“结构保持型”引导，是因为平滑、归一化和裁剪在经验上限制了局部梯度更新对轨迹整体形状的破坏；这一表述不构成形式化的稳定性或安全性证明。连续动力学采用显式 Euler 法离散积分，其建模形式与神经常微分方程一致 [3]。

## 3.6 算法与实现配置

### 算法 1：VTF-Flow 的可行性感知训练

```text
输入：按序列划分的训练集 D；车辆状态相关地形场 F_VT；权重 λ_VT
输出：速度场参数 θ

1:  repeat
2:      从 D 采样场景及真实未来轨迹 (S, x_1)
3:      编码历史状态、目标点和局部地形，得到条件向量 c
4:      采样 x_0 ~ N(0, I) 与 t ~ U(0, 1)
5:      构造 x_t = (1-t)x_0 + tx_1，并令 u_t = x_1 - x_0
6:      预测 v_θ(x_t, t, c)，计算基础 Flow Matching 损失 L_FM
7:      由 x_t 与 v_θ 估计清洁轨迹 x̂_1
8:      从 x̂_1 估计候选速度与可靠航向，并查询 F_VT
9:      计算 L_VT 及总损失 L = L_FM + λ_VT L_VT
10:     反向传播 L 并更新 θ
11: until 收敛或达到预设训练轮数
```

### 算法 2：结构保持型可行性引导采样

```text
输入：场景 S；训练后的速度场 v_θ；地形代价场；样本数 K；积分步数 N
输出：候选轨迹集合 {τ^(k)}_(k=1)^K

1:  编码场景一次，得到条件向量 c，并沿候选维复制 K 份
2:  并行采样 X_0 ∈ R^(K×H×3)，其中各候选服从 N(0, I)
3:  for n = 0, …, N-1 do
4:      令 t_n = n/N，并计算 V_n = v_θ(X_n, t_n, c)
5:      由 X_n 与 V_n 估计清洁候选轨迹 X̂_1
6:      计算每条候选的车辆状态相关平均地形代价 J_VT
7:      求梯度 G_n = ∇_(X_n) Σ_k J_VT^(k)
8:      对 G_n 执行时间平滑、RMS 归一化、低范数抑制与 L2 裁剪
9:      令 η_n = 0.2 t_n，并更新 X_(n+1) = X_n + (V_n - η_n Ḡ_n)/N
10: end for
11: 返回 X_N 作为 K 条候选轨迹
```

最终配置采用三层速度残差 MLP、192 维场景嵌入、零 dropout、\(N=16\) 个 Euler 步和 \(K=8\) 个并行候选。梯度裁剪上限为 4.0，归一化稳定项为 \(10^{-8}\)，低范数阈值为 \(10^{-7}\)。为使主方法保持单一且可复现，最终配置不启用 trust-region 修正或自适应触发；这些机制仅作为消融选项。模型输出为 \([B,K,H,3]\)，后续使用 ADE、FDE、minADE@K、minFDE@K、多样性、平滑度、地形代价、违规率和推理延迟进行评价。

## 参考文献

[1] Jiang, P., Osteen, P. R., Wigness, M. B. & Saripalli, S. RELLIS-3D Dataset: Data, Benchmarks and Analysis. *2021 IEEE International Conference on Robotics and Automation (ICRA)*, 1110–1116 (2021). https://doi.org/10.1109/ICRA48506.2021.9561251

[2] Lipman, Y., Chen, R. T. Q., Ben-Hamu, H., Nickel, M. & Le, M. Flow Matching for Generative Modeling. *International Conference on Learning Representations* (2023). https://openreview.net/forum?id=PqvMRDCJT9t

[3] Chen, R. T. Q., Rubanova, Y., Bettencourt, J. & Duvenaud, D. Neural Ordinary Differential Equations. *Advances in Neural Information Processing Systems 31* (2018). https://proceedings.neurips.cc/paper/2018/hash/69386f6bb1dfed68692a24c8686939b9-Abstract.html
