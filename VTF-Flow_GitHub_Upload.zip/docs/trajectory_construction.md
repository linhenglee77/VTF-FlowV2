# RELLIS-3D future trajectory construction

## Scope

VTF-Flow constructs fixed-time future position targets from the locally
available RELLIS-3D pose rows. This document describes the implemented matrix
algebra, timestamp sampling, validity checks, and the verified RELLIS-3D
planning-coordinate adapter.

The implementation is in `datasets/trajectory_builder.py`. It does not train a
model and does not alter the source dataset.

## Input pose contract and verified planning convention

The trajectory formula requires each input to mean `T_world_ego(t)`: a
homogeneous transform that maps coordinates from the ego frame at time `t` into
a common world frame. A row from `poses.txt` contains 12 floating-point values
and is loaded into the first three rows of a 4x4 matrix; `[0, 0, 0, 1]` is
appended as the final row.

The released local archives and official dataset description identify these as
poses for each Ouster scan. Rigid-transform continuity rules out interpreting
the numeric rows as their inverse. A local calibration-bag TF audit, all-five-
sequence motion statistics, and the existing trajectory-cache convention agree
on a 180-degree yaw basis change from `ouster1/os1_lidar` to VTF-Flow's
base-link-aligned planning axes.

`rellis3d_os1_to_planning_ego()` is the reviewed adapter. It right-multiplies
each `T_world_lidar` by `diag(-1,-1,1,1)`, producing x-forward, y-left, z-up
planning coordinates while retaining the LiDAR scan origin. The default generic
adapter remains a no-op so non-RELLIS callers do not receive a hidden dataset-
specific transform. Full evidence and remaining calibration caveats are in
`docs/rellis3d_coordinate_verification.md`.

## Relative transform

For a current frame `t` and future frame `t+i`, the implementation uses exactly:

```text
T_local_future(i) = inverse(T_world_ego(t)) @ T_world_ego(t+i)
```

For homogeneous transforms

```text
T_world_ego(t)   = [ R_t  p_t ]
                   [  0    1  ]

T_world_ego(t+i) = [ R_i  p_i ]
                   [  0    1  ],
```

the extracted future translation is equivalently:

```text
p_local(i) = R_t^T @ (p_i - p_t).
```

The future rotation `R_i` does not affect the requested `(x_i, y_i, z_i)`
translation. The trajectory tensor therefore contains:

```text
trajectory = [p_local(1), ..., p_local(H)]   # shape [H, 3]
```

The current point is not duplicated in this future tensor. It is computed and
stored separately as:

```text
origin = translation(inverse(T_world_ego(t)) @ T_world_ego(t))
       = (0, 0, 0), up to numerical tolerance.
```

This preserves VTF-Flow's version-one `i = 1, ..., H` trajectory contract while
still explicitly validating the current ego origin.

## Time sampling and interpolation

RELLIS RGB names contain a frame index and decimal timestamp, for example:

```text
frame000000-1581624652_750.jpg
```

The loader interprets the portion after the hyphen as an integer seconds field
plus a decimal fraction scaled by its number of digits. Timestamp `n` is joined
to pose row `n` only because the local audit found exact continuous index-set
equality for RGB, Ouster, and pose rows. This association remains an observed
export relationship, not proof of hardware synchronization.

Default sampling configuration:

| Parameter | Default |
| --- | ---: |
| Prediction horizon | 5.0 s |
| Sampling interval | 0.5 s |
| Future samples `H` | 10 |
| Minimum raw future frames | 10 |
| Translation interpolation | enabled |

Target times are `t + 0.5, t + 1.0, ..., t + 5.0` seconds. With interpolation
enabled, each target world translation is linearly interpolated between its two
bracketing pose timestamps. The right-bracketing rotation is retained because
future rotation does not enter the version-one translation output; VTF-Flow
does not invent an orientation interpolation convention before yaw is added to
the public trajectory state.

With interpolation disabled, the nearest timestamped pose is selected for each
target. The chosen source indices are retained in `EgoTrajectory` for auditing.
In both modes, input timestamps must be finite and strictly increasing, the
requested horizon must be covered, and the configured minimum number of raw
future frames must be available.

## Validity checks

Every built trajectory is checked before it is returned:

1. All pose-derived coordinates and timestamps must be finite.
2. Current and target timestamps must be strictly increasing.
3. `inverse(T_current) @ T_current` must place the current ego translation
   within `origin_tolerance` of `(0, 0, 0)`.
4. Distance between every adjacent pair—including origin to the first future
   point—must not exceed `max_teleport_distance`.
5. Segment distance divided by target-time difference must not exceed the
   configurable `max_speed_mps` threshold.

The threshold is named `max_speed_mps` for the intended verified metric pose
contract, but while pose translation units remain unresolved it numerically acts
on pose-units per second. It must be revisited when the pose convention is
authoritatively established. Invalid builds raise `TrajectoryValidationError`;
the individual checks and observed maxima are available in `TrajectoryValidity`.

## Visualization

Run from the VTF-Flow project directory:

```bash
python scripts/visualize_gt_trajectories.py \
  --data-root <PATH> \
  --num-samples 75
```

The script uses a fixed random seed by default, samples valid current frames
across all discovered sequences, and writes PNGs plus `manifest.csv` under
`outputs/debug_gt_trajectories/`. Each image overlays the current origin and ten
future GT samples, with the third local coordinate encoded by color.

Raw LiDAR BEV can be requested with `--with-lidar`. Because the audit has not
verified the pose-frame-to-LiDAR-frame relationship, this overlay is explicitly
marked “alignment unverified” and must not be used as calibration evidence.
