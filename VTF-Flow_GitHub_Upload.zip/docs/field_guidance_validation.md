# 车辆条件地形场 guidance 验证

## 决策

重新校准后，当前场已经具备**保守、弱强度 feasibility guidance 的研究可用性**，
推荐先限制在约 5 个更新步，并与生成模型目标和轨迹平滑约束共同使用。它仍不适合
20 步强引导，也不能被解释成安全判定器。

支持该判断的证据是：

- 四类扰动均由 GT 获得更高平均 F；GT 配对胜率为 57.6%–77.6%，障碍定向扰动
  达到 77.6%、Cohen's dz=0.701；
- 所有梯度有限且非零，近障碍负梯度有 93.4%–96.5% 指向远离障碍方向；
- 1 cm 抖动后的梯度方向余弦为 0.9963–0.9976，极端梯度率为 0；
- 5 步下降使 99.8% 的轨迹 F 提升，平均占用暴露从 0.924% 降至 0.417%；
- 但 smoothness 在 5、10、20 步后分别变为初始的 1.42、2.04、3.10 倍，
  因而长程 field-only 优化仍失败。

F 始终仅作为相对连续分数；没有使用或暗示 `F<0.5` 是安全阈值。

## 固定验证设置

- 序列：trajectory cache `train` 中完整序列 00004；
- GT 数：1,909；每条 30 个未来 waypoint，间隔 0.5 s；
- 梯度质量子集：均匀抽取 128 条，每类扰动 128 次；
- field-only 下降子集：同样均匀抽取 128 条；步数 5/10/20；
- 坐标：`configs/rellis3d_os1_to_planning_ego.json`；
- 坐标状态：`verified_T_planning_ego_os1_lidar_from_local_tf_and_pose_audit`；
- semantic 权重：1.0 → 0.35；unknown 权重：0.8 → 0.15；
- 场空间高斯平滑：σ=0.5 m；轨迹梯度高斯平滑：σ=1 waypoint；
- 其余扰动、学习率 0.05 m、单 waypoint 最大更新 0.10 m 均保持不变；
- 没有调用或修改 Flow/回归 planner 架构。

## 配对判别

正的 Delta F 表示 GT 得分更高。置信区间为 10,000 次 scene-level paired
bootstrap 的均值 95% 区间。

| 扰动 | GT mean F | 扰动 mean F | Delta F | 95% CI | GT 胜率 | dz |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| smooth spatial | 0.566484 | 0.555731 | +0.010752 | [0.009517, 0.012056] | 69.57% | 0.377 |
| local rotation | 0.566484 | 0.565349 | +0.001134 | [0.000842, 0.001418] | 57.62% | 0.174 |
| controlled offset | 0.566484 | 0.556997 | +0.009487 | [0.007449, 0.011546] | 62.28% | 0.209 |
| obstacle directed | 0.566484 | 0.553083 | +0.013400 | [0.012554, 0.014269] | 77.58% | 0.701 |

四类差值均为正且置信区间不跨零。local rotation 仍只有小效应，这并不意外：
局部小角度旋转可以继续位于同一可通行走廊内。场对障碍定向扰动的中等偏大效应
最能支持其用于相对 guidance，但通用扰动并未达到接近完美的可分性。

## 成本分解

GT waypoint 的加权贡献如下：

| 分量 | 均值 | 方差 |
| --- | ---: | ---: |
| semantic | 0.156535 | 0.001003 |
| slope | 0.076651 | 0.008874 |
| roughness | 0.013704 | 0.000349 |
| occupancy | 0.029913 | 0.008929 |
| clearance | 0.177672 | 0.052476 |
| unknown | 0.094950 | 0.002584 |
| speed conditioning total | 0.073264 | 0.008559 |
| speed-slope | 0.016460 | 0.000440 |
| speed-roughness | 0.003535 | 0.000026 |
| speed-clearance | 0.053270 | 0.006975 |

semantic+unknown 占 terrain-only GT 平均成本的 45.8%，由旧版 61.7% 降低；
它们仍是重要先验，但不再压倒 geometry/clearance。各分量之和重构 terrain 与
vehicle-conditioned 总成本的最大误差小于 `3.0e-8`。

## 梯度质量

| 扰动 | 中位 magnitude | P95 | Max | zero | extreme | 远离障碍 cosine | 远离比例 | 1 cm jitter cosine |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| smooth | 0.00562 | 0.03820 | 0.14147 | 0% | 0% | 0.784 | 93.44% | 0.99759 |
| rotation | 0.00506 | 0.03406 | 0.09514 | 0% | 0% | 0.847 | 95.96% | 0.99646 |
| offset | 0.00557 | 0.03769 | 0.12440 | 0% | 0% | 0.853 | 96.49% | 0.99632 |
| obstacle | 0.00616 | 0.03781 | 0.10685 | 0% | 0% | 0.852 | 96.21% | 0.99714 |

极端阈值仍为 0.5 cost/m，zero 阈值仍为 `1e-8`。全部 512 次梯度诊断成功。
空间平滑将旧版 P95 约 0.46–0.48 降至 0.034–0.038，并把 1 cm 抖动敏感度
从 1.40–2.53 /m 降至 0.100–0.111 /m。梯度更稳定，但尺度也更小，未来 guidance
仍需归一化、裁剪与保守步长。

## Field-only 梯度下降

下表对四类扰动取平均：

| 步数 | 初始 F | 最终 F | Delta F | 改善比例 | 初始占用 | 最终占用 | 平均位移 | 最大位移 | smoothness 比 |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 5 | 0.55810 | 0.59264 | +0.03454 | 99.80% | 0.924% | 0.417% | 0.221 m | 0.500 m | 1.42x |
| 10 | 0.55810 | 0.61220 | +0.05410 | 98.24% | 0.924% | 0.189% | 0.408 m | 1.000 m | 2.04x |
| 20 | 0.55810 | 0.62441 | +0.06631 | 91.99% | 0.924% | 0.085% | 0.646 m | 2.000 m | 3.10x |

5 步是当前较合理的起点：几乎所有路径提高相对 F，位移受控且占用暴露下降；
但 smoothness 仍恶化 42%。10–20 步虽然继续提高场分数，却越来越多地利用
waypoint 高频自由度，不应直接用于训练或采样。

## 与旧版的关键变化

| 指标 | 旧版 | 新版 |
| --- | ---: | ---: |
| 坐标 | unverified identity | 已核验 180° yaw planning transform |
| obstacle-directed GT 胜率 | 54.74% | 77.58% |
| obstacle-directed dz | 0.129 | 0.701 |
| 近障碍远离比例 | 82.3–82.9% | 93.4–96.5% |
| extreme-gradient ratio | 3.8–4.8% | 0% |
| 1 cm jitter cosine | 0.951–0.988 | 0.996–0.998 |
| 5-step smoothness ratio | 2.76x | 1.42x |
| 20-step smoothness ratio | 4.08x | 3.10x |

改善主要来自正确坐标对齐，其次来自降权和空间/时间平滑。不能把这些结果解释为
场已经校准到真实车辆失效概率；semantic 成本仍是文档化先验，不是 RELLIS 标签。

## 完整性检查与复现

- summary 行数：71；per-scene 行数：7,636 = 1,909×4；
- obstacle-directed 可构造率：100%；
- gradient failure：0；descent failure：0；
- 分量重构最大误差：`2.94e-8`。

```powershell
python scripts/validate_field_guidance.py `
  --data-root <RELLIS3D_ROOT> `
  --cache-root <TRAJECTORY_CACHE_ROOT> `
  --split train --sequence 00004 `
  --sensor-to-ego configs/rellis3d_os1_to_planning_ego.json `
  --gradient-scenes 128 --descent-scenes 128 `
  --output outputs/experiments/field_guidance_validation.csv
```
