# Formal TVK validation

| Method | minADE@K (m) | Vehicle cost | Kinematic cost | TVK cost | Curvature violation | Lateral-accel violation | Smoothness (m) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Flow baseline | 0.5313 ± 0.0385 | 0.6845 ± 0.0066 | 0.0055 ± 0.0012 | 0.6899 ± 0.0066 | 0.0209 ± 0.0035 | 0.0000 ± 0.0000 | 0.0225 ± 0.0045 |
| VTF-Flow w/o feasibility training and kinematic terms | 0.5315 ± 0.0365 | 0.6766 ± 0.0044 | 0.0055 ± 0.0013 | 0.6821 ± 0.0045 | 0.0208 ± 0.0037 | 0.0000 ± 0.0000 | 0.0226 ± 0.0046 |
| VTF-Flow w/o kinematic terms | 0.5114 ± 0.0451 | 0.6756 ± 0.0042 | 0.0047 ± 0.0009 | 0.6803 ± 0.0049 | 0.0212 ± 0.0027 | 0.0000 ± 0.0000 | 0.0213 ± 0.0022 |
| VTF-Flow w/o inference-time guidance | 0.5238 ± 0.0504 | 0.6821 ± 0.0057 | 0.0046 ± 0.0007 | 0.6867 ± 0.0053 | 0.0197 ± 0.0014 | 0.0000 ± 0.0000 | 0.0213 ± 0.0054 |
| VTF-Flow w/o feasibility training | 0.5313 ± 0.0364 | 0.6767 ± 0.0045 | 0.0051 ± 0.0011 | 0.6818 ± 0.0045 | 0.0197 ± 0.0035 | 0.0000 ± 0.0000 | 0.0226 ± 0.0046 |
| VTF-Flow (ours) | 0.5222 ± 0.0470 | 0.6738 ± 0.0034 | 0.0043 ± 0.0006 | 0.6781 ± 0.0030 | 0.0187 ± 0.0013 | 0.0000 ± 0.0000 | 0.0214 ± 0.0054 |

## Evidence interpretation

The primary protocol uses three independently trained seeds and a held-out test sequence. All feasibility and violation quantities are model-based diagnostics, not calibrated safety probabilities. Scene-level paired intervals are descriptive because neighbouring frames are temporally correlated; cross-sequence robustness is reported separately.

- VTF-Flow (ours) versus the Flow baseline: unified TVK cost 0.6899 -> 0.6781; minADE@K 0.5313 -> 0.5222.
- VTF-Flow (ours) versus VTF-Flow w/o kinematic terms: unified TVK cost 0.6803 -> 0.6781; curvature violation 0.0212 -> 0.0187.
- Paired A vs VTF, minADE@K_m: mean difference -0.009127, 95% CI [-0.012435, -0.005821], BH-FDR p=7.07e-05.
- Paired A vs VTF, mean_unified_tvk_cost: mean difference -0.011829, 95% CI [-0.012479, -0.011228], BH-FDR p=6.4e-213.
- Paired A vs VTF, curvature_violation_rate: mean difference -0.002196, 95% CI [-0.002770, -0.001611], BH-FDR p=2.86e-12.
- Paired A vs VTF, lateral_acceleration_violation_rate: mean difference +0.000000, 95% CI [+0.000000, +0.000000], BH-FDR p=1.
- Paired A vs VTF, smoothness_m: mean difference -0.001120, 95% CI [-0.001188, -0.001046], BH-FDR p=2.83e-175.

## Boundary

Curvature and lateral acceleration are trajectory-derived kinematic proxies. A continuous displacement-reliability gate attenuates curvature when adjacent waypoint displacement is insufficient for a stable estimate. The nominal limits are planning hyperparameters because RELLIS-3D does not provide reliable tyre-terrain friction or complete vehicle parameters. The results therefore do not establish full vehicle dynamics or formal safety.
