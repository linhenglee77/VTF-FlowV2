# 3 方法

## 3.1 问题定义与总体框架

非结构化越野环境通常缺少明确的车道中心线、道路边界与规则化通行区域，车辆可选择的行驶空间因而呈现连续、开放且高度依赖地形的特征。对于同一局部目标，车辆可能通过不同方向或不同几何形态的轨迹完成向前行驶；然而，这些轨迹是否适合车辆通行，不仅取决于其几何位置，还受到坡度、地表起伏、障碍物分布以及行驶速度等因素的共同影响。因此，本文关注的并非单一参考路径的几何拟合，而是面向局部目标的多候选车辆轨迹生成，以及生成过程中车辆运动状态与地形通行条件的协调。

设 \(t\) 为当前规划时刻，车辆获得局部目标点 \(\mathbf g_t\) 和以车辆为中心的局部地形表征 \(\mathbf M_t\)。规划器输出 \(K\) 条候选未来轨迹：

\[
\mathcal S_t=\{\mathbf g_t,\mathbf M_t\},\qquad
\boldsymbol\tau_t^{(k)}=\{\mathbf p_{t+i}^{(k)}\}_{i=1}^{H},\qquad
\mathbf p_{t+i}^{(k)}=(x_{t+i}^{(k)},y_{t+i}^{(k)},z_{t+i}^{(k)}),
\tag{1}
\]

其中，\(H\) 为规划时域内的离散轨迹点数。所有轨迹均表示在当前车辆的局部 planning-ego 坐标系中，当前车辆位置映射至原点，\(x\) 轴沿车辆前进方向，\(y\) 轴指向车辆左侧，\(z\) 轴指向上方。当前冻结实现保留了历史状态接口，但未使用真实车辆历史作为有效条件，因此本文将规划输入严格限定为局部目标与地形表征。

本文提出 VTF-Flow（Vehicle-Conditioned Terrain Feasibility-Guided Flow Planning）。该方法不把地形可行性作为轨迹生成结束后的有效性检查，而是将其构造为可微的统一地形–车辆运动学可行性势，并把势能梯度直接嵌入 Flow Matching 的生成动力学。具体而言，条件 Flow Matching 首先学习符合示范驾驶分布的数据驱动轨迹先验；局部地形随后被转换为连续地形势场，并依据每条候选轨迹诱导的速度、可靠航向、曲率和横向加速度扩展为轨迹相关势能；在每个数值积分步，规划器均根据当前生成状态恢复净轨迹估计，计算统一势能梯度，并在同一次状态更新中将轨迹推向较低代价区域。因此，生成主干回答“何种轨迹符合真实驾驶分布”，可行性分支回答“势场沿何种方向下降以及当前候选应如何修正”，两者共同决定候选轨迹的生成过程。

需要说明的是，条件 Flow Matching 在本文中承担多候选轨迹生成主干，其本身并非本文强调的独立创新。VTF-Flow 的方法增量体现在三个相互衔接的层面。第一，构建统一的地形–车辆运动学可行性势场表示，将占用、不可通行性、坡度、粗糙度和障碍邻近度编码为连续空间势场，并通过候选速度、可靠航向、曲率及横向加速度将其提升为轨迹相关势能。第二，在轨迹空间中进行条件生成，使场景约束和运动学约束能够直接作用于完整未来轨迹，而不是仅作用于单个位置或生成后的候选排序。第三，将统一轨迹势能对当前 Flow 状态的梯度，经轨迹协调处理后连续注入数值积分，使可行性修正贯穿从随机状态到候选轨迹的整个演化过程。由此，VTF-Flow 形成“数据驱动轨迹先验＋生成过程内势场修正”的规划机制，区别于“静态可通行地图＋生成后检查”的处理范式。

VTF-Flow 的整体框架如图 1 所示。蓝色部分表示以局部目标和 terrain BEV 为条件的随机轨迹生成主干；绿色部分构造从静态地形势场到车辆状态条件势、再到统一轨迹势能的层级表示；红色部分表示训练阶段的联合监督；青色部分表示推理阶段的生成过程内势场引导。第 3.2 节介绍面向局部目标的轨迹生成过程，第 3.3 节定义统一可行性势场与轨迹势能，第 3.4 和第 3.5 节分别给出训练正则与推理引导的耦合方式。

![VTF-Flow总体方法框架](figures/vtf_flow_framework_final.png)

**图 1｜VTF-Flow 总体框架。** 局部目标点和三通道 terrain BEV 构成规划场景条件，Goal-anchored Flow network 从随机初始状态生成多条未来车辆轨迹。Terrain BEV 被转换为由占用、不可通行性、坡度、粗糙度和障碍邻近度共同构成的连续空间势场；候选轨迹进一步诱导速度、可靠航向、曲率和横向加速度，从而将空间势场提升为统一轨迹势能。训练阶段在净轨迹估计上施加有界可行性正则；推理阶段则在每个 Euler 积分步计算轨迹势能梯度，经轨迹协调处理后直接修正 Flow 状态。势场由此进入轨迹生成动力学，而非作为生成后的筛选或后处理模块。图中局部地形和轨迹仅用于解释信息流，不构成方法间的定量比较。

## 3.2 面向局部目标的轨迹空间生成

在缺少车道拓扑的越野场景中，局部目标提供车辆总体行驶方向，但不能唯一确定具体通行路径。为同时保持目标导向性和候选轨迹多样性，VTF-Flow 采用目标锚定的条件 Flow Matching 建模未来轨迹分布。场景编码器将 terrain BEV 与局部目标编码为条件向量 \(\mathbf c_t\)，其中地形表征描述车辆周围的可通行空间，目标坐标描述当前规划任务的期望行进方向和距离。

使用 \(s\in[0,1]\) 表示生成过程中的 Flow time，并与实际交通场景的物理时刻 \(t\) 区分。令干净的监督轨迹为 \(\mathbf x_1=\boldsymbol\tau_t^{\mathrm{gt}}\)，初始随机轨迹状态为 \(\mathbf x_0\sim\mathcal N(\mathbf0,\mathbf I)\)。训练时在二者之间构造线性概率路径，并使条件速度场逼近对应输运速度 [1]：

\[
\mathbf x_s=(1-s)\mathbf x_0+s\mathbf x_1,\qquad
\mathcal L_{\mathrm{FM}}
=\mathbb E\!\left[\left\|\mathbf v_\theta(\mathbf x_s,s,\mathbf c_t)
-(\mathbf x_1-\mathbf x_0)\right\|_2^2\right].
\tag{2}
\]

仅依赖场景条件的速度场可能减弱局部目标对长时域行驶方向的约束。为此，VTF-Flow 在速度场中引入由目标点构造的参考输运，并由网络学习相对于该参考的空间残差和速度残差：

\[
\boldsymbol\mu_{\theta,i}
=\frac{i}{H}\mathbf g_t+\mathbf r_{\theta,i}(\mathbf c_t),\qquad
\mathbf v_\theta
=\frac{\boldsymbol\mu_\theta-\mathbf x_s}{\max(1-s,\varepsilon)}
+\Delta\mathbf v_\theta(\mathbf x_s,s,\mathbf c_t).
\tag{3}
\]

这一参数化使候选轨迹总体朝局部目标推进，但不将最后一个轨迹点硬性固定在目标位置，从而为绕行障碍物和适应地形留出空间。在任意生成时刻，可由当前轨迹状态和预测速度恢复净轨迹估计（clean trajectory estimate）：

\[
\widehat{\mathbf x}_1^{(s)}
=\mathbf x_s+(1-s)\mathbf v_\theta(\mathbf x_s,s,\mathbf c_t).
\tag{4}
\]

该估计对应当前生成状态所指向的完整未来车辆轨迹，也是后续计算速度、航向和地形代价的统一轨迹空间载体。推理时从不同高斯初始状态并行积分可得到 \(K\) 条候选轨迹。不同候选反映模型学习到的轨迹分布差异，但本文不预先将其解释为具有明确语义标签的驾驶行为模式。

## 3.3 统一的地形–车辆运动学可行性势场与轨迹势能

### 3.3.1 连续地形可行性势场

为使生成轨迹能够感知越野地形，规划器使用与轨迹相同局部坐标系下的三通道 terrain BEV：

\[
\mathbf M_t=\{T,O,\bar Z\},
\tag{5}
\]

其中，\(T\) 表示栅格内可通行点比例，\(O\) 表示障碍物点密度，\(\bar Z\) 表示归一化平均高度。由这三个基础通道进一步构造障碍物占用代价 \(C_o\)、不可通行代价 \(C_{nt}\)、坡度代价 \(C_s\)、粗糙度代价 \(C_r\) 和障碍邻近度代价 \(C_d\)。这些分量分别描述局部空间是否被占用、地表是否允许车辆通过、纵横向高程变化、地表起伏程度以及车辆与邻近障碍物之间的空间裕度。

将各分量归一化到一致量纲后，基础地形可行性势场及其对应的连续可行性分数写为

\[
C_T(\mathbf p)=
\frac{\sum_{m\in\{o,nt,s,r,d\}}w_m C_m(\mathbf p)}{\sum_m w_m},
\qquad
F_T(\mathbf p)=\exp[-\beta C_T(\mathbf p)].
\tag{6}
\]

其中，\(w_m\geq0\) 为各地形因素的权重，\(\beta>0\) 控制代价到可行性分数的映射尺度。轨迹点处的地形属性通过双线性插值查询，因此 \(C_T\) 和 \(F_T\) 相对于平面轨迹坐标保持连续并可用于梯度计算。在势场解释下，标量函数 \(C_T(\mathbf p)\) 即局部地形可行性势：其数值描述位置的相对运行代价，负梯度 \(-\nabla_{\mathbf p}C_T\) 给出局部降低地形代价的方向，而 \(F_T\) 只是该势的有界单调映射。这里的 \(F_T\in(0,1]\) 是相对通行偏好，而不是经标定的安全概率。与经典人工势场 [2] 不同，本文不在 \(C_T\) 中设置目标吸引势；目标导向由第3.2节的条件生成主干提供，地形势场仅承担可行性修正，从而避免用手工吸引–排斥规则替代学习到的驾驶先验。

### 3.3.2 车辆状态条件化的地形可行性势

相同地形并不必然对应相同的车辆通行条件。例如，高速通过坡面或粗糙区域通常比低速通过产生更高的运行风险；随速度上升，车辆对前方障碍物间距的要求也会增加。因此，VTF-Flow 不把地形代价视为仅由位置决定的静态地图，而是依据候选轨迹自身的运动状态对其进行调整。

对净轨迹估计中的相邻轨迹点进行有限差分，得到各规划时刻的候选速度 \(v_i\) 和切向航向 \(\psi_i\)。当相邻点位移过小时，连续航向可靠度会减弱方向信息，避免低速状态下不稳定的航向估计影响地形查询。在可靠航向方向上查询前视障碍邻近度后，车辆状态相关代价可概括为

\[
C_{\mathrm{VT},i}
=C_T(\mathbf p_i)
+q(v_i)\!\left[
\alpha_s C_s(\mathbf p_i)
+\alpha_r C_r(\mathbf p_i)
+\alpha_d C_{d,i}^{\mathrm{eff}}(\mathbf p_i,\psi_i)
\right],
\qquad
F_{\mathrm{VT},i}=\exp[-\beta C_{\mathrm{VT},i}],
\tag{7}
\]

其中，\(q(v_i)\) 为随速度连续增长的非负函数，\(\alpha_s,\alpha_r,\alpha_d\) 分别控制速度对坡度、粗糙度和障碍邻近度的放大作用。由此，\(C_{\mathrm{VT}}(\mathbf p;v,\psi)\) 构成车辆状态条件化的地形势：同一空间位置可因候选轨迹的速度或行进方向不同而对应不同势值。因此，完整的车辆条件势不能被解释为一幅与候选轨迹无关的固定二维热图；只有其静态空间部分 \(C_T(x,y)\) 可直接显示在 BEV 中。

### 3.3.3 轨迹运动学代价与统一轨迹势能

仅有逐点地形代价仍不足以描述整条轨迹的几何连续性及其速度耦合效应。本文在当前车辆原点与未来轨迹点之间构造平面轨迹段，由相邻三点的外接圆关系估计曲率 \(\kappa_i\)，并计算横向加速度代理 \(a_{y,i}=v_i^2|\kappa_i|\)。当任一相邻轨迹段过短、不足以支撑稳定转向估计时，由局部位移控制的连续曲率可靠度会衰减 \(\kappa_i\) 及相应横向加速度代理，从而避免近静止定位抖动垄断统一目标，同时保持关于轨迹坐标的可微性。曲率和横向加速度均通过相对于名义上限的可微软超限函数 \(\phi(\cdot)\) 转化为无量纲惩罚；低于上限的状态保持较小代价，超过上限后代价连续增加。统一代价与有界可行性定义为

\[
C_{\mathrm{TVK},i}=C_{\mathrm{VT},i}
+w_\kappa\phi_\kappa(|\kappa_i|)
+w_a\phi_a(a_{y,i}),
\qquad
F_{\mathrm{TVK},i}=F_{\mathrm{VT},i}
\exp\!\left[-w_\kappa\phi_\kappa(|\kappa_i|)
-w_a\phi_a(a_{y,i})\right].
\tag{8}
\]

其中，\(w_\kappa\) 和 \(w_a\) 分别控制曲率与横向加速度的贡献。沿候选轨迹对 \(C_{\mathrm{TVK},i}\) 求平均得到统一轨迹势能 \(J_{\mathrm{TVK}}\)。因此，\(C_T\) 描述静态空间势场，\(C_{\mathrm{VT}}\) 描述状态条件势，而 \(J_{\mathrm{TVK}}\) 描述整条候选轨迹在当前场景和运动状态下的广义势能。这一层级使地形位置、候选速度与航向以及曲率–速度耦合统一作用于轨迹坐标，并保持可微。需要强调的是，\(F_{\mathrm{TVK}}\) 表示相对连续可行性，而非经标定的安全概率；曲率与横向加速度也仅属于可由候选轨迹稳定计算的运动学代理。由于数据中缺少可信的轮胎–地面附着、轴距、转向极限、质量和侧倾稳定参数，本文不将该表示解释为完整车辆动力学模型或稳定性保证。

统一可行性在训练与推理阶段采用互补形式：训练阶段使用有界分数 \(F_{\mathrm{TVK}}\) 构造稳定的软正则，以调整模型对不同轨迹区域的相对偏好；推理阶段使用连续代价 \(J_{\mathrm{TVK}}\) 保留空间梯度，并将其作为生成过程内的引导信号。由此，第3.3节定义的可行性表示分别连接到第3.4节的联合训练和第3.5节的Flow演化。

## 3.4 统一可行性正则化的 Flow Matching 训练

VTF-Flow 保留基础 Flow Matching 目标，并将统一的地形–车辆运动学可行性作为附加软正则，而不是重新定义生成任务。一次训练迭代中，首先采样高斯初始状态和 Flow time，构造线性概率路径并预测条件速度；随后由式（4）恢复净轨迹估计，从中计算速度、可靠航向、曲率与横向加速度，再查询每个轨迹点的 \(F_{\mathrm{TVK}}\)。最终训练目标为

\[
\mathcal L
=\mathcal L_{\mathrm{FM}}
+\lambda_{\mathrm{TVK}}
\frac{1}{BH}\sum_{b=1}^{B}\sum_{i=1}^{H}
\left[1-F_{\mathrm{TVK},b,i}\right].
\tag{9}
\]

上述计算保留在同一自动微分图中，因此可行性正则能够沿 \(\widehat{\mathbf x}_1^{(s)}\rightarrow\mathbf v_\theta\rightarrow\theta\) 的计算路径反馈至条件速度场。基础 Flow Matching 的线性概率路径、目标速度和均方误差形式均保持不变，\(\mathcal L_{\mathrm{TVK}}\) 仅改变模型对不同轨迹区域的相对偏好。指数映射使单点正则保持有界，有助于避免少数极端代价在训练早期压倒轨迹分布学习。该项的交通含义是提高模型对较低地形与运动学运行代价轨迹的偏好，而不是把示范轨迹或某一分数阈值定义为绝对安全标签。基础目标与可行性正则之间的权衡由 \(\lambda_{\mathrm{TVK}}\) 控制；若使用额外平顺性正则，则将其作为独立损失项设置，不并入 \(F_{\mathrm{TVK}}\)，从而保持各约束贡献可解释。

\begin{algorithm}[t]
\caption{统一地形–车辆运动学可行性正则化的 VTF-Flow 训练}
\label{alg:vtf_training}
\begin{algorithmic}[1]
\Require 训练场景 \(\mathcal S_t=\{\mathbf g_t,\mathbf M_t\}\)，监督轨迹 \(\mathbf x_1\)，条件速度场 \(\mathbf v_\theta\)，可行性权重 \(\lambda_{\mathrm{TVK}}\)
\Ensure 更新后的模型参数 \(\theta\)
\For{每个训练批次}
    \State 编码局部目标和 terrain BEV，得到场景条件 \(\mathbf c_t\)
    \State 采样 \(\mathbf x_0\sim\mathcal N(\mathbf0,\mathbf I)\) 和 \(s\sim\mathcal U(0,1)\)
    \State 构造 \(\mathbf x_s=(1-s)\mathbf x_0+s\mathbf x_1\) 及目标速度 \(\mathbf u_s=\mathbf x_1-\mathbf x_0\)
    \State 计算 \(\mathbf v_s=\mathbf v_\theta(\mathbf x_s,s,\mathbf c_t)\) 和 \(\mathcal L_{\mathrm{FM}}=\|\mathbf v_s-\mathbf u_s\|_2^2\)
    \State 恢复净轨迹估计 \(\widehat{\mathbf x}_1^{(s)}=\mathbf x_s+(1-s)\mathbf v_s\)
    \State 从 \(\widehat{\mathbf x}_1^{(s)}\) 估计速度、可靠航向、曲率及横向加速度
    \State 查询 \(F_{\mathrm{TVK}}\)，计算 \(\mathcal L_{\mathrm{TVK}}=\operatorname{mean}(1-F_{\mathrm{TVK}})\)
    \State 计算 \(\mathcal L=\mathcal L_{\mathrm{FM}}+\lambda_{\mathrm{TVK}}\mathcal L_{\mathrm{TVK}}\)
    \State 通过梯度下降更新 \(\theta\)
\EndFor
\end{algorithmic}
\end{algorithm}

算法 \ref{alg:vtf_training} 将基础输运学习和统一的地形–车辆运动学偏好置于同一次参数更新中。可行性分支只改变训练目标，不改变 Flow Matching 的概率路径和目标速度，因此消融实验可以分别识别生成主干、地形条件化以及运动学正则的贡献。

## 3.5 生成过程内的可行性势场引导 Flow 演化

训练阶段的软正则不能保证每个随机样本都具有较低运行代价，因此 VTF-Flow 在推理阶段进一步把统一轨迹势能 \(J_{\mathrm{TVK}}\) 作为生成动力学中的在线修正。对于每个场景，规划器首先并行采样 \(K\) 个高斯初始轨迹状态。在每个数值积分步，网络根据当前状态、Flow time 和场景条件预测生成速度，并恢复对应的净轨迹估计；随后计算候选车辆速度、可靠航向、曲率与横向加速度，沿轨迹查询 \(C_{\mathrm{TVK}}\)，并对轨迹势能求梯度。该梯度通过完整计算链 \(\mathbf x_s\rightarrow\mathbf v_\theta\rightarrow\widehat{\mathbf x}_1^{(s)}\rightarrow J_{\mathrm{TVK}}\) 回传至当前 Flow 状态，因此它改变的是生成状态的下一步演化方向，而不是最终轨迹的后处理结果。

逐轨迹点的原始梯度可能受局部栅格变化影响而产生高频振荡。为保持相邻轨迹点修正方向的协调性，本文采用轨迹协调算子 \(\mathcal A(\cdot)\)，依次执行轨迹维平滑、逐候选尺度归一化、低梯度抑制和轨迹级范数裁剪。引导后的连续动力学写为

\[
\frac{d\mathbf x}{ds}
=\mathbf v_\theta(\mathbf x_s,s,\mathbf c_t)
-\eta(s)\,\mathcal A\!\left(
\nabla_{\mathbf x_s}
J_{\mathrm{TVK}}(\widehat{\mathbf x}_1^{(s)})
\right),
\qquad
J_{\mathrm{TVK}}=\frac1H\sum_{i=1}^{H}C_{\mathrm{TVK},i}.
\tag{10}
\]

式（10）由两部分共同驱动：\(\mathbf v_\theta\) 提供从示范轨迹学习的数据驱动生成方向，\(-\mathcal A(\nabla J_{\mathrm{TVK}})\) 则可解释为轨迹空间中的广义可行性势场力，\(\eta(s)\) 控制该力在不同 Flow 时刻的作用强度。数值求解时，学习到的生成速度与势场力在同一个 Euler 更新中共同作用于 \(\mathbf x_s\)。因而，势场修正贯穿从随机轨迹状态到完整候选轨迹的演化过程，而不是在生成结束后删除、重排或重新优化高代价样本。早期阶段以保持学习到的总体轨迹结构为主，后期在轨迹逐渐成形后加强局部可行性调整。

\begin{algorithm}[t]
\caption{统一地形–车辆运动学可行性引导的 VTF-Flow 演化}
\label{alg:vtf_sampling}
\begin{algorithmic}[1]
\Require 场景条件 \(\mathbf c_t\)，terrain BEV \(\mathbf M_t\)，训练后的 \(\mathbf v_\theta\)，候选数 \(K\)，Euler 步数 \(N\)，引导函数 \(\eta(s)\)
\Ensure 候选轨迹集合 \(\{\boldsymbol\tau_t^{(k)}\}_{k=1}^{K}\)
\State 并行采样 \(\mathbf x_0^{(k)}\sim\mathcal N(\mathbf0,\mathbf I),\;k=1,\ldots,K\)
\For{\(n=0,\ldots,N-1\)}
    \State 设置 \(s_n=n/N\)，计算 \(\mathbf v_n=\mathbf v_\theta(\mathbf x_n,s_n,\mathbf c_t)\)
    \State 恢复 \(\widehat{\mathbf x}_1^{(s_n)}=\mathbf x_n+(1-s_n)\mathbf v_n\)
    \State 从 \(\widehat{\mathbf x}_1^{(s_n)}\) 估计速度、可靠航向、曲率及横向加速度
    \State 计算统一代价 \(J_{\mathrm{TVK}}=H^{-1}\sum_i C_{\mathrm{TVK},i}\)
    \State 求取原始引导梯度 \(\mathbf G_n=\nabla_{\mathbf x_n}J_{\mathrm{TVK}}\)
    \State 计算协调梯度 \(\bar{\mathbf G}_n=\mathcal A(\mathbf G_n)\)
    \State 更新 \(\mathbf x_{n+1}=\mathbf x_n+N^{-1}[\mathbf v_n-\eta(s_n)\bar{\mathbf G}_n]\)
\EndFor
\State \Return \(\{\mathbf x_N^{(k)}\}_{k=1}^{K}\)
\end{algorithmic}
\end{algorithm}

算法 \ref{alg:vtf_sampling} 表明，可行性引导不是独立于生成器的后处理优化，而是每个数值积分步中的动力学组成项。该流程同时保留来自不同随机初始状态的候选差异，并通过受控梯度更新降低统一地形–车辆运动学代价。若令 \(\eta(s)=0\)，算法严格退化为原始条件 Flow 采样；因此，是否启用生成过程内引导及其贡献可通过配对消融直接识别。

VTF-Flow 最终输出形状为 \([B,K,H,3]\) 的候选轨迹集合。本文所称“主动向可行域演化”，严格指轨迹在生成过程中朝更低 \(J_{\mathrm{TVK}}\)、更高相对连续可行性的方向更新，并不意味着轨迹必然进入某个预先定义的硬安全集合。进一步地，“结构保持”表示通过梯度平滑和范数限制减少局部振荡与异常位移，“运动学可行性”表示对曲率和横向加速度代理施加连续软约束，均不等同于完整车辆动力学可执行性证明。该方法不提供硬碰撞约束、闭环稳定性或形式化安全保证，因此仍需从轨迹误差、候选多样性、运动平顺性、地形违规、运行代价和计算延迟等方面进行统一评价。

## 参考文献

[1] Lipman, Y., Chen, R. T. Q., Ben-Hamu, H., Nickel, M. & Le, M. Flow Matching for Generative Modeling. *International Conference on Learning Representations* (2023). https://openreview.net/forum?id=PqvMRDCJT9t

[2] Khatib, O. Real-Time Obstacle Avoidance for Manipulators and Mobile Robots. *The International Journal of Robotics Research* **5**, 90–98 (1986). https://doi.org/10.1177/027836498600500106
