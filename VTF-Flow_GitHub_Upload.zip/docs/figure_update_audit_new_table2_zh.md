# 完整 VTF-Flow 主表与消融图件审计

## 审计结论

表 2 的主方法已恢复为与方法章节一致的完整 VTF-Flow，即训练期使用有界 TVK 正则、推理期使用 TVK 势引导。其 1,909 个测试场景、3 个随机种子结果来自 `outputs/unified_h10_benchmark/runs/`。**VTF-Flow w/o TVK training (optimized guidance)** 仅作为表 3 的消融变体，预测保存在 `outputs/unified_h10_benchmark_optimized/runs/`。因此，主文基准图、地形机理图和相机--BEV 图必须使用完整模型；优化引导变体只能在明确标为 ablation 的图件中出现。

## 主文图件

| 图件 | 结论 | 处理方式 | 原因 |
|---|---|---|---|
| 图 1 方法框架 | 基本无需修改 | 保留结构；若右下候选轨迹来自旧预测，可在最终统一出图时替换 | 方法结构和公式未改变，表 2 数值不进入框架图 |
| 图 2 GT 轨迹构造与坐标验证 | 无需修改 | 直接保留 | 仅依赖位姿、时间戳和 planning-ego 变换，与规划模型输出无关 |
| 图 3 基准方法场景比较 | 使用完整模型 | 若当前图已读取 `unified_h10_benchmark/runs/VTF_seed*`，可以保留；否则重绘 | 主文图必须与表 2 的完整模型一致 |
| 图 4A--C 地形机理场景 | 使用完整模型 | 静态地形底图可保留；核对叠加轨迹是否来自完整 VTF 缓存 | 地形层不变，轨迹层必须匹配主模型 |
| 图 5 相机--BEV 跨视角解释 | 使用完整模型 | 核对候选投影、逐点 TVK 和色标均来自完整模型 | 相机叠加依赖具体候选，不能混用消融预测 |
| 消融轨迹图 | 单独生成 | 同时展示 Flow、完整 VTF 与 w/o TVK training，并明确标注 | 用于解释训练正则与推理引导的差异，不进入主基准图 |

## 输出目录影响

### `raw_terrain_scenes_unified_h10/benchmark_comparison`

该目录用于主文基准比较时，应读取完整 VTF-Flow 预测。若现有 PNG、PDF、SVG 和 TIFF 已由 `outputs/unified_h10_benchmark/` 生成且图中数值与逐场景 CSV 一致，可以继续使用。若场景按方法优势筛选，图注必须说明筛选规则，并由全测试集表 2 作为主要证据。

### `raw_terrain_scenes_unified_h10/terrain_mechanism`

目录中 6 个场景若是依据 GT 几何类别选择，场景和静态地形层可以保持不变。应确认叠加的 VTF 候选、oracle 轨迹和场景级 TVK 标注来自完整模型，而不是优化引导消融变体。

### 相机--BEV 图组

所有 `figure_camera_bev_tvk_*` 图件中的主方法轨迹都应来自完整 VTF-Flow。原始相机图、标定和静态地形场可以复用；需要核对：

1. 完整 VTF-Flow 候选的 planning-ego 轨迹；
2. 正深度和画面范围过滤后的可见点数量；
3. 候选逐点 TVK 势；
4. 跨场景 pooled q95 显示上限；
5. 图注中的可见点数和场景级解释。

### 旧版 `raw_terrain_scenes`

该目录中的图应根据预测来源分类。完整 VTF-Flow 图可以用于主文；`w/o TVK training` 和 `w/o kinematic feasibility` 图只能用于消融分析；仅显示原始地形属性、GT 或静态势场的版本可以继续作为数据与表示诊断图。

## 不应采用的更新方式

- 不应把消融变体的 0.1375、0.1069 或 0.5945 写入主表或完整模型图注。
- 不应根据新总体均值人工移动某一场景中的轨迹线。
- 不应继续使用按旧模型优势筛选的场景，同时把图注改写成新模型结果。
- 不应把静态地形势值当作完整 TVK 值；完整 TVK 仍需沿新候选逐点评价。

## 重新出图所需最小输入

要核验图 3--图 5，至少需要：

1. 1,909 个测试场景、3 个随机种子的完整 VTF-Flow 预测，每个文件形状为 `[1909, 8, 10, 3]`；
2. 与预测逐场景对齐的 scene ID、sequence ID 和 frame ID；
3. 新模型逐场景 ADE-0、minADE@8、TVK、地形违规、曲率违规和平顺性；
4. 完整模型所用的随机种子、VTF checkpoint 与引导配置；
5. 与当前主表一致的地形场、阈值和候选聚合协议。

完整模型输入位于 `outputs/unified_h10_benchmark/`；无 TVK 训练消融输入位于 `outputs/unified_h10_benchmark_optimized/`。两者都已齐备，但必须分别用于主文和消融图件。

## 新预测到位后的重绘入口

将新预测保存为统一 benchmark 目录后，可继续使用现有 Python 出图入口：

```powershell
python scripts/render_unified_raw_terrain_scenes.py `
  --data-root <RELLIS3D_ROOT> `
  --benchmark-root <NEW_BENCHMARK_ROOT> `
  --output-root <NEW_FIGURE_ROOT>

python scripts/render_camera_bev_tvk_interpretation.py `
  --data-root <RELLIS3D_ROOT> `
  --benchmark-root <NEW_BENCHMARK_ROOT>
```

正式生成时应输出到新目录，完成逐图核验后再替换主文引用，避免覆盖仍可追溯的旧版图件。
