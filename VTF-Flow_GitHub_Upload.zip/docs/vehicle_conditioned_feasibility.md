# Vehicle-conditioned terrain feasibility

## 状态与结论

车辆状态条件地形场已经实现，并使用核验后的 RELLIS-3D Ouster LiDAR 到
planning-ego 变换重新评估。第一版状态只包含速度 `v` 和可靠时的平面 heading
`psi`，没有引入缺乏稳健重力对齐与车体姿态证据的 pitch/roll。

在相同轨迹上，vehicle-conditioned field 相对 terrain-only field 始终降低平均
feasibility、增加平均 cost，说明速度相关 slope、roughness 和 clearance 响应按设计
生效。这里的 F 只用于相对比较，不是碰撞概率；CSV 中 `F<0.5` 相关列仅保留为
诊断统计，不能解释成安全阈值。

## 公共接口

```python
feasibility = field.query(xyz_or_xy, vehicle_state)
```

- `xyz_or_xy`：形状 `[...,2]` 或 `[...,3]`；当前只查询平面位置。
- `vehicle_state["speed"]`：非负速度，单位 m/s。
- `vehicle_state["heading"]`：可选局部平面航向角，单位 rad。
- `vehicle_state["heading_reliability"]`：可选连续置信度 `[0,1]`。

状态张量必须可广播到去掉坐标轴后的 query shape。缺失 speed 时，附加车辆成本
为零；只有 heading 而没有显式 reliability 时按可靠处理。轨迹调用方应使用
`trajectory_motion_state()`，它会由相邻 waypoint 连续计算 speed、heading 和软可靠度。

## 可微速度响应

定义连续速度响应：

```text
r(v) = clamp(v / v_ref, 0, r_max)^p
```

车辆附加成本为：

```text
Delta C_slope = g_slope * r(v) * C_slope
Delta C_rough = g_rough * r(v) * C_rough

d_required(v) = d_base + g_distance * r(v)
C_clear(v, psi) = sigmoid((d_required(v) - d_effective(psi)) / tau)
Delta C_clear = g_clear * r(v) * C_clear(v, psi)

Delta C_vehicle = Delta C_slope + Delta C_rough + Delta C_clear
F_vehicle = F_terrain * exp(-Delta C_vehicle)
```

因此静止时 `F_vehicle == F_terrain`。提高速度会连续增强 slope/roughness 惩罚并
增大所需 clearance，不使用离散速度 if/else。

可靠 heading 的前视位置为：

```text
(x_look, y_look) = (x, y) + v * t_look * (cos(psi), sin(psi))
```

当前 clearance 与前视 clearance 的较小值通过 `heading_reliability` 连续混合。
轨迹 heading 可靠度为：

```text
q_heading = sigmoid((segment_displacement - d_min) / d_soft)
```

几乎静止的 segment 不会因 `atan2(0,0)` 或不可靠方向产生硬切换。实现还使用
`1e-6 m` 数值范数下限，重复 waypoint 的反向传播保持有限。

所有参数均位于 `configs/rellis3d_terrain_field.json` 的
`vehicle_conditioning` 段，包括速度参考、响应指数、三个增益、clearance 要求、
softness 和 heading look-ahead。

## 三种比较表示

1. **Binary traversability**：raw occupancy 小于 0.5、semantic cost 小于 0.5，
   且 geometry 已观测时为 1，否则为 0。
2. **Terrain-only continuous**：平滑后的 geometry、semantic、occupancy、slope、
   roughness、clearance 和 unknown 连续成本。
3. **Vehicle-conditioned continuous**：terrain-only 成本加上上述 motion-state
   附加项。

Binary 的均值表示可行 waypoint 比例，与连续 F 的数值尺度不同，不能直接把二者
当作同一个概率比较。

## 比较实验

实验使用 regression-vs-flow 定性集合中序列 00004 的 9 个代表场景：

- 9 条 GT；
- 9 条 deterministic Regression 输出；
- 9 条 Flow candidate 0；
- 9 条按 GT ADE 选择的 Flow oracle best-of-10，仅用于分析；
- 全部 90 条 Flow 候选。

所有轨迹含 30 个 waypoint，间隔 0.5 s。点云使用
`configs/rellis3d_os1_to_planning_ego.json` 中核验的 180° yaw 变换；地形成本使用
降权后的 semantic/unknown 及 `sigma=0.5 m` 空间平滑。

| 轨迹来源 | Binary F | Terrain F | Vehicle F | Terrain cost | Vehicle cost | Delta F | Delta cost | Mean speed |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| GT | 0.5593 | 0.6630 | 0.6417 | 0.4344 | 0.4808 | -0.0214 | +0.0464 | 0.955 m/s |
| Regression | 0.3000 | 0.6639 | 0.6475 | 0.4234 | 0.4570 | -0.0164 | +0.0335 | 0.820 m/s |
| Flow candidate 0 | 0.3222 | 0.6622 | 0.6446 | 0.4310 | 0.4689 | -0.0175 | +0.0379 | 0.842 m/s |
| Flow oracle best-of-10 | 0.3370 | 0.6601 | 0.6414 | 0.4364 | 0.4778 | -0.0187 | +0.0414 | 0.839 m/s |
| Flow all 10 | 0.3115 | 0.6557 | 0.6373 | 0.4429 | 0.4839 | -0.0185 | +0.0411 | 0.834 m/s |

五类来源的 `Delta F` 均为负、`Delta cost` 均为正，且更快的 GT 获得最大的平均
motion-state cost 增量。这验证了机制方向，但 9 个定性场景不足以支持 planner 排名。
特别是 oracle best-of-10 使用 GT 选择，不能作为部署时 selector。

## 坐标与解释边界

CSV 的坐标状态为：

```text
verified_T_planning_ego_os1_lidar_from_local_tf_and_pose_audit:
rellis3d_os1_to_planning_ego.json
```

planning-ego 使用 LiDAR 原点、base-link 对齐方向。完整外参证据和校准 bag 内重复
静态边的不确定性见 `docs/rellis3d_coordinate_verification.md`。这解决了本项目场与
轨迹的轴对齐问题，但不构成测量级外参或车辆安全认证。

## 产物与复现

- `outputs/experiments/field_comparison.csv`：15 条聚合记录；
- `outputs/experiments/field_comparison_per_scene.csv`：135 条逐场景记录；
- `outputs/experiments/field_comparison_before_coordinate_verification.csv`：旧 identity
  诊断结果，仅供追溯。

```powershell
python scripts/evaluate_vehicle_conditioned_field.py `
  --data-root <RELLIS3D_ROOT> `
  --cache-root <TRAJECTORY_CACHE_ROOT> `
  --split train `
  --sensor-to-ego configs/rellis3d_os1_to_planning_ego.json `
  --output outputs/experiments/field_comparison.csv
```

在把该场接入强 guidance 或用于安全结论前，仍需使用车辆结果或专家 passability
标签校准 semantic 与速度响应，并在更大 planner 输出集合上验证 sensitivity。
