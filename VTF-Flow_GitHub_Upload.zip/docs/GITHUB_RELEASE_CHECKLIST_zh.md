# VTF-Flow GitHub 投稿发布清单

## 必须进入普通 Git 的内容

- `configs/`：所有冻结配置与验证集阈值；
- `datasets/`、`models/`、`planners/`、`terrain/`、`guidance/`、`metrics/`、
  `evaluation/`、`closed_loop/`：运行时源码；
- `scripts/`：缓存构建、训练、评价与绘图入口；
- `tests/`：单元测试；
- `docs/`：数据审计、坐标核验、轨迹构造和方法说明；
- `reproducibility/`：论文主表及势场诊断的参考数值；
- `README.md`、`pyproject.toml`、`requirements.txt`、`.gitignore`。

## 不应直接提交到普通 Git 的内容

- 原始 RELLIS-3D 数据；
- `data/`、`outputs/`、训练 checkpoint、预测 `.npz`、大体积 `.npy`；
- 含本机绝对路径的临时日志；
- 未确认授权的第三方图片或数据副本。

GitHub 普通 Git 对单文件实施 100 MiB 上限，因此大文件应进入 GitHub Release、
Git LFS 或 Zenodo 等归档。优先建议将“源码”和“大体积复现实验包”分开发布，
避免每次 clone 都下载模型和预测。

## 建议发布的三个归档

1. `vtf-flow-cache-v1.tar.gz`
   - `trajectory_cache_h150_s5/` 全目录；
   - `dataset_config.json`；
   - SHA-256 清单。
2. `vtf-flow-frozen-models-v1.tar.gz`
   - `outputs/sequence_holdout_robustness/`；
   - `outputs/sequence_holdout_full_benchmark/checkpoints/`；
   - SHA-256 清单。
3. `vtf-flow-reference-results-v1.tar.gz`
   - 主基准 CSV/JSON/TeX；
   - 势场前置验证 CSV；
   - 消融实验表；
   - 论文最终采用图及 source data；
   - 每次运行的 `effective_protocol.json`。

## 公开前必须由作者确认

- [ ] 确定软件许可证并添加根目录 `LICENSE`；
- [ ] 确认 RELLIS-3D 第三方数据条款，并避免将原始数据误写为作者自有数据；
- [ ] 创建 GitHub 仓库 URL 和版本标签；
- [ ] 上传上述大体积归档；
- [ ] 生成并核对每个归档的 SHA-256；
- [ ] 将 GitHub release 归档到 Zenodo 或同类仓库并取得 DOI；
- [ ] 在 README、论文 Code Availability 和 Data Availability 中填入同一版本、URL 与 DOI；
- [ ] 用一台不含 `D:\\Uroad` 的干净机器或容器执行 README 全流程；
- [ ] 检查源码中不存在个人邮箱密码、令牌、私有数据链接或无关绝对路径；
- [ ] 核对 `reproducibility/reference_main_table.csv` 与论文最终表格完全一致。

## 推荐的论文可用性表述（待填永久链接后使用）

> The source code, frozen experiment configurations, reference metrics, and
> instructions required to reproduce the analyses are available at [GitHub
> URL], release [version]. The corresponding large-file artifact bundle is
> archived at [repository and DOI]. RELLIS-3D is a third-party dataset and is
> available from its original providers under their applicable terms; raw
> RELLIS-3D data are not redistributed with this repository.

方括号内容必须在正式投稿材料中替换，不能保留占位符。
