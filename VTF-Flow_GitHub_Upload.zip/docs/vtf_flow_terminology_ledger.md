# VTF-Flow terminology ledger

| Canonical term | Symbol | Meaning | Do not conflate with |
|---|---|---|---|
| Static terrain-feasibility potential field | \(C_T(x,y)\) | Continuous position-dependent terrain operating cost queried from the planner BEV | A calibrated safety probability or goal-attraction field |
| Terrain-feasibility score | \(F_T=\exp(-\beta C_T)\) | Bounded monotone mapping of the static potential; higher is relatively more feasible | A binary traversability label or safety threshold |
| Vehicle-state-conditioned terrain potential | \(C_{\mathrm{VT}}(\mathbf p;v,\psi)\) | Static terrain potential augmented by speed- and reliable-heading-dependent terrain penalties | A fixed 2D heatmap independent of a candidate trajectory |
| Unified trajectory potential | \(J_{\mathrm{TVK}}\) | Mean candidate-level potential combining vehicle-conditioned terrain cost with curvature and lateral-acceleration soft penalties | A complete vehicle-dynamics energy or formal safety certificate |
| Feasibility-potential force | \(-\mathcal P_g[\mathcal A(\nabla J_{\mathrm{TVK}})]\) | Coordinated, norm-controlled, endpoint-preserving descent direction injected into each Flow integration update | Post-generation filtering or independent trajectory optimisation |
| Feasibility score | \(F_{\mathrm{TVK}}\) | Bounded relative preference used for training regularisation | A probability of collision-free or dynamically stable execution |
| Planning-ego coordinate frame | -- | Current-vehicle-centred frame in which the ego position is the origin and future trajectories are represented | The world frame or an unresolved raw sensor frame |
| Recorded ground-truth future trajectory | GT | Future vehicle motion reconstructed from timestamped RELLIS-3D poses | A road centreline, unique optimal path, or calibrated safe trajectory |
| Three-channel terrain BEV | \(\mathbf M_t=\{T,O,\bar Z\}\) | Planner input containing traversable-point fraction, obstacle-point density, and normalised mean elevation | The derived static terrain-feasibility potential field \(C_T\) |
| ADE-0 | -- | ADE of the first non-oracle sampled candidate, retained as the implementation/reporting name | minADE@\(K\) or an online selected trajectory |
| Benchmark method | -- | CV, A* terrain planner, deterministic regression, or unguided Flow Matching | An internal VTF-Flow ablation variant |
| VTF-Flow | -- | Final frozen method with bounded TVK training regularisation and endpoint-preserving in-flow TVK guidance; this is the name used in the main benchmark and manuscript narrative | A manuscript method named ``V2''; versioned cache identifiers are provenance only |
| VTF-Flow (full) | -- | Label for the complete VTF-Flow configuration only within component-ablation tables and their immediate discussion; it is placed after all reduced variants | A separate benchmark method or a new model version |
| VTF-Flow w/o kinematic potential | -- | Component ablation that retains the vehicle-state-conditioned terrain potential but removes curvature and lateral-acceleration terms during training and guidance | The complete VTF-Flow method |
| VTF-Flow w/o training regularisation | -- | Diagnostic inference-guidance variant without TVK training regularisation; its separately optimised guidance settings prevent a strict one-factor causal interpretation | The complete VTF-Flow method or a benchmark method |

The local goal is handled by the goal-conditioned generative backbone. It is not
encoded as a hand-crafted attractive term in the terrain-feasibility potential.
